package com.focuslock.app.core

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** طريقة حساب: زاوية الفجر وزاوية العشاء (أو دقائق بعد المغرب إن كانت [ishaMin] > 0). */
data class CalcMethod(
    val key: String,
    val ar: String,
    val en: String,
    val fajr: Double,
    val isha: Double,
    val ishaMin: Int = 0
)

/**
 * حساب مواقيت الصلاة داخل التطبيق بلا إنترنت، بمعادلات فلكية معيارية (مثل PrayTimes.org).
 * الترتيب دائماً: الفجر، الظهر، العصر، المغرب، العشاء.
 */
object PrayerTimes {
    val METHODS = listOf(
        CalcMethod("MWL", "رابطة العالم الإسلامي — الجزائر (18°/17°)", "Muslim World League — Algeria (18°/17°)", 18.0, 17.0),
        CalcMethod("EGYPT", "الهيئة المصرية (19.5°/17.5°)", "Egyptian Authority (19.5°/17.5°)", 19.5, 17.5),
        CalcMethod("UMM", "أم القرى (18.5° والعشاء +90 د)", "Umm al-Qura (18.5°, Isha +90 min)", 18.5, 0.0, 90),
        CalcMethod("KARACHI", "كراتشي (18°/18°)", "Karachi (18°/18°)", 18.0, 18.0),
        CalcMethod("ISNA", "أمريكا الشمالية (15°/15°)", "North America (15°/15°)", 15.0, 15.0),
        CalcMethod("MOROCCO", "المغرب (19°/17°)", "Morocco (19°/17°)", 19.0, 17.0),
        CalcMethod("TURKEY", "تركيا (18°/17°)", "Turkey (18°/17°)", 18.0, 17.0)
    )

    fun method(key: String): CalcMethod = METHODS.firstOrNull { it.key == key } ?: METHODS[0]

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun dsin(d: Double) = sin(rad(d))
    private fun dcos(d: Double) = cos(rad(d))
    private fun dtan(d: Double) = tan(rad(d))
    private fun fixA(a: Double) = a - 360.0 * floor(a / 360.0)
    private fun fixH(h: Double) = h - 24.0 * floor(h / 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** (ميل الشمس، معادلة الزمن) */
    private fun sunPos(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixA(357.529 + 0.98560028 * d)
        val q = fixA(280.459 + 0.98564736 * d)
        val l = fixA(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixH(deg(atan2(dcos(e) * dsin(l), dcos(l))) / 15.0)
        val eqt = q / 15.0 - ra
        val decl = deg(asin(dsin(e) * dsin(l)))
        return decl to eqt
    }

    private fun midDay(jd: Double, t: Double) = fixH(12.0 - sunPos(jd + t).second)

    private fun angleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sunPos(jd + t).first
        val noon = midDay(jd, t)
        val x = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))
        if (x > 1.0 || x < -1.0) return Double.NaN
        val tt = deg(acos(x)) / 15.0
        return noon + (if (ccw) -tt else tt)
    }

    private fun asrTime(jd: Double, lat: Double, factor: Double, t: Double): Double {
        val decl = sunPos(jd + t).first
        val angle = -deg(atan2(1.0, factor + dtan(abs(lat - decl))))
        return angleTime(jd, lat, angle, t, false)
    }

    /** ساعات اليوم المحلية: [فجر، ظهر، عصر، مغرب، عشاء]، وقد تكون NaN في خطوط العرض العالية. */
    fun hours(
        year: Int, month: Int, day: Int,
        lat: Double, lng: Double, tz: Double, m: CalcMethod, adjustMin: Int
    ): DoubleArray {
        val jd = julian(year, month, day) - lng / (15.0 * 24.0)
        var fajr = 5.0
        var dhuhr = 12.0
        var asr = 13.0
        var sunset = 18.0
        var isha = 18.0
        var sunrise = 6.0
        repeat(2) {
            val tf = fajr / 24.0
            val td = dhuhr / 24.0
            val ta = asr / 24.0
            val ts = sunset / 24.0
            val ti = isha / 24.0
            val tr = sunrise / 24.0
            fajr = angleTime(jd, lat, m.fajr, tf, true)
            dhuhr = midDay(jd, td)
            asr = asrTime(jd, lat, 1.0, ta)
            sunset = angleTime(jd, lat, 0.833, ts, false)
            isha = angleTime(jd, lat, m.isha, ti, false)
            sunrise = angleTime(jd, lat, 0.833, tr, true)
        }
        val adj = tz - lng / 15.0
        val maghrib = sunset + adj
        val ishaFinal = if (m.ishaMin > 0) maghrib + m.ishaMin / 60.0 else isha + adj
        val a = adjustMin / 60.0
        // الفهرس 5: الشروق (نهاية وقت الفجر)، ولا يتأثر بضبط الدقائق
        return doubleArrayOf(fajr + adj + a, dhuhr + adj + a, asr + adj + a, maghrib + a, ishaFinal + a, sunrise + adj)
    }

    /** أوقات الصلوات الخمس (0..4) والشروق (5) بالميلي ثانية ليوم (اليوم + [dayOffset])، أو null إن تعذّر الحساب. */
    fun forDay(
        lat: Double, lng: Double, m: CalcMethod, adjustMin: Int,
        dayOffset: Int, nowMs: Long = System.currentTimeMillis()
    ): LongArray? {
        val cal = Calendar.getInstance()
        cal.timeInMillis = nowMs
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        val y = cal.get(Calendar.YEAR)
        val mo = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val midnight = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 12)
        val tz = TimeZone.getDefault().getOffset(cal.timeInMillis) / 3600000.0
        val h = hours(y, mo, d, lat, lng, tz, m, adjustMin)
        if (h.any { it.isNaN() }) return null
        // تقريب لأقرب دقيقة كما في المرجع (وإلا قد يظهر الوقت أقل بدقيقة عن المنشور)
        return LongArray(5) { midnight + Math.round(h[it] * 60.0) * 60000L }
    }
}
