package com.focuslock.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.focuslock.app.core.Cities
import com.focuslock.app.core.PrayerScheduler
import com.focuslock.app.core.PrayerTimes
import com.focuslock.app.core.SessionManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.produceState
import com.focuslock.app.core.Dnd
import com.focuslock.app.core.L
import com.focuslock.app.data.Pomo
import com.focuslock.app.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.focuslock.app.core.Apps
import com.focuslock.app.data.AppSettings
import com.focuslock.app.data.LockMode
import com.focuslock.app.data.Store

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val st by Store.settingsFlow.collectAsState()
    var picking by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    fun save(n: AppSettings) = Store.saveSettings(n)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle(L.tr("الإعدادات", "Settings"))

        SectionCard {
            SectionTitle(L.tr("المظهر واللغة", "Appearance & language"))
            Text(L.tr("المظهر", "Theme"), fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipOption(st.theme == ThemeMode.AUTO, L.tr("تلقائي", "Auto")) { save(st.copy(theme = ThemeMode.AUTO)) }
                ChipOption(st.theme == ThemeMode.LIGHT, L.tr("فاتح", "Light")) { save(st.copy(theme = ThemeMode.LIGHT)) }
                ChipOption(st.theme == ThemeMode.DARK, L.tr("داكن", "Dark")) { save(st.copy(theme = ThemeMode.DARK)) }
            }
            Spacer(Modifier.height(8.dp))
            Text(L.tr("اللغة", "Language"), fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipOption(st.language == "auto", L.tr("لغة النظام", "System language")) { save(st.copy(language = "auto")) }
                ChipOption(st.language == "ar", "العربية") { save(st.copy(language = "ar")) }
                ChipOption(st.language == "en", "English") { save(st.copy(language = "en")) }
            }
        }

        SectionCard {
            SectionTitle(L.tr("الهدف وبومودورو", "Goal & Pomodoro"))
            Stepper(
                L.tr("هدف التركيز اليومي", "Daily focus goal"), fmtMin(st.dailyGoalMin),
                { save(st.copy(dailyGoalMin = (st.dailyGoalMin - 15).coerceAtLeast(15))) },
                { save(st.copy(dailyGoalMin = (st.dailyGoalMin + 15).coerceAtMost(720))) }
            )
            Spacer(Modifier.height(4.dp))
            Text(
                L.tr("القيم الافتراضية لبومودورو (يمكن تغييرها لكل جلسة):", "Pomodoro defaults (can be changed per session):"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            PomoEditor(Pomo(st.pomoFocus, st.pomoBreak, st.pomoLongBreak, st.pomoCycles)) {
                save(st.copy(pomoFocus = it.focusMin, pomoBreak = it.breakMin, pomoLongBreak = it.longBreakMin, pomoCycles = it.cycles))
            }
        }

        SectionCard {
            SectionTitle(L.tr("وضع القفل", "Lock mode"))
            RadioRow(
                st.lockMode == LockMode.ALL_EXCEPT_ALLOWED,
                L.tr("قفل كامل ما عدا المسموح", "Full lock except allowed apps"),
                L.tr("كل التطبيقات محجوبة عدا التي تختارها (الاتصال والرسائل افتراضياً).", "All apps are blocked except those you choose (calls and messages by default).")
            ) { save(st.copy(lockMode = LockMode.ALL_EXCEPT_ALLOWED)) }
            RadioRow(
                st.lockMode == LockMode.ONLY_SELECTED,
                L.tr("حجب تطبيقات محددة فقط", "Block selected apps only"),
                L.tr("تُحجب التطبيقات التي تختارها وحدها، وبقية الهاتف يعمل.", "Only the apps you choose are blocked; the rest of the phone works.")
            ) { save(st.copy(lockMode = LockMode.ONLY_SELECTED)) }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (st.lockMode == LockMode.ALL_EXCEPT_ALLOWED)
                        L.tr("التطبيقات المسموحة (${st.allowedApps.size})", "Allowed apps (${st.allowedApps.size})")
                    else L.tr("التطبيقات المحجوبة (${st.blockedApps.size})", "Blocked apps (${st.blockedApps.size})")
                )
            }
            Text(
                L.tr("المكالمات والطوارئ ولوحة المفاتيح والشاشة الرئيسية مسموحة دائماً.", "Calls, emergency, keyboard and home screen are always allowed."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        PrayerSection(st) { save(it) }

        SectionCard {
            SectionTitle(L.tr("الصرامة والحماية", "Strictness & protection"))
            SwitchRow(
                L.tr("عدم الإزعاج أثناء التركيز", "Do Not Disturb while focusing"),
                L.tr("اختياري: يكتم الإشعارات أثناء الجلسة ثم يعيد حالته السابقة بعدها. يحتاج إذن الوصول لسياسة الإشعارات.",
                    "Optional: silences notifications during a session and restores your previous state afterwards. Needs notification-policy access."),
                st.dnd
            ) {
                save(st.copy(dnd = it))
                if (it && !Dnd.granted(ctx)) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    } catch (e: Exception) { /* تجاهل */ }
                }
            }
            SwitchRow(
                L.tr("حماية الإعدادات أثناء الجلسة", "Protect Settings during a session"),
                L.tr("حجب تطبيق الإعدادات ومثبّت التطبيقات لمنع تعطيل القفل أو حذف التطبيق.", "Blocks the Settings app and package installer to prevent disabling the lock or uninstalling."),
                st.protectSettings
            ) { save(st.copy(protectSettings = it)) }
            SwitchRow(
                L.tr("السماح بالإنهاء المبكر", "Allow early finish"),
                L.tr("عند إنجاز كل المهام يمكنك إنهاء الجلسة المقفلة قبل انتهاء الوقت.", "When all tasks are done you can end a locked session early."),
                st.earlyFinish
            ) { save(st.copy(earlyFinish = it)) }
            SwitchRow(
                L.tr("تنبيه قبل النهاية بدقيقتين", "Warn 2 minutes before the end"),
                L.tr("إشعار يذكّرك بقرب انتهاء الوقت.", "A notification reminds you time is almost up."),
                st.warnBeforeEnd
            ) { save(st.copy(warnBeforeEnd = it)) }
            SwitchRow(
                L.tr("صوت واهتزاز عند انتهاء الوقت", "Sound & vibration at the end"),
                L.tr("ينبّهك صوتياً واهتزازياً عند النهاية (يحترم وضع الصامت).", "Alerts you with sound and vibration (respects silent mode)."),
                st.endAlert
            ) { save(st.copy(endAlert = it)) }
            Stepper(
                L.tr("انتظار الخروج الطارئ", "Emergency exit wait"),
                L.tr("${st.exitDelaySec} ثانية", "${st.exitDelaySec} s"),
                { save(st.copy(exitDelaySec = (st.exitDelaySec - 10).coerceAtLeast(10))) },
                { save(st.copy(exitDelaySec = (st.exitDelaySec + 10).coerceAtMost(120))) }
            )
            Stepper(
                L.tr("الحد الأقصى للتمديد", "Maximum extensions"),
                if (st.maxExtensions == 0) L.tr("بلا حد", "Unlimited") else L.tr("${st.maxExtensions} مرات", "${st.maxExtensions} times"),
                { save(st.copy(maxExtensions = (st.maxExtensions - 1).coerceAtLeast(0))) },
                { save(st.copy(maxExtensions = (st.maxExtensions + 1).coerceAtMost(10))) }
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(L.tr("رمز PIN للخروج الطارئ", "Emergency-exit PIN"), fontWeight = FontWeight.Bold)
                    Text(
                        if (st.pin.isEmpty()) L.tr("غير مفعّل", "Off") else L.tr("مفعّل", "On"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (st.pin.isNotEmpty()) {
                    TextButton(onClick = { save(st.copy(pin = "")) }) { Text(L.tr("حذف", "Remove")) }
                }
                OutlinedButton(onClick = { pinDialog = true }) {
                    Text(if (st.pin.isEmpty()) L.tr("تعيين", "Set") else L.tr("تغيير", "Change"))
                }
            }
        }

        SectionCard {
            SectionTitle(L.tr("الأذونات والجاهزية", "Permissions & readiness"))
            PermissionsPanel()
        }

        SectionCard {
            Text("Tarkeez 2.0", fontWeight = FontWeight.Bold)
            Text(
                L.tr("كل بياناتك تبقى على هاتفك فقط. التطبيق لا يطلب إذن الإنترنت ولا يرسل أي شيء.",
                    "All your data stays on your phone. The app has no internet permission and sends nothing."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(12.dp))
    }

    if (picking) {
        val isAllowed = st.lockMode == LockMode.ALL_EXCEPT_ALLOWED
        AppPickerDialog(
            title = if (isAllowed) L.tr("التطبيقات المسموحة", "Allowed apps") else L.tr("التطبيقات المحجوبة", "Blocked apps"),
            initial = if (isAllowed) st.allowedApps else st.blockedApps,
            onSave = {
                save(if (isAllowed) st.copy(allowedApps = it) else st.copy(blockedApps = it))
                picking = false
            },
            onDismiss = { picking = false }
        )
    }

    if (pinDialog) {
        PinDialog(
            onSave = { save(st.copy(pin = it)); pinDialog = false },
            onDismiss = { pinDialog = false }
        )
    }
}

@Composable
private fun ChipOption(selected: Boolean, label: String, onClick: () -> Unit) {
    val tick = rememberTick()
    FilterChip(selected = selected, onClick = { tick(); onClick() }, label = { Text(label) })
}

@Composable
private fun RadioRow(selected: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = { tick(); onChange(it) })
    }
}

@Composable
private fun PinDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("رمز PIN", "PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(L.tr("يُطلب عند الخروج الطارئ. اختر رمزاً من 4 إلى 8 أرقام، ويُفضّل أن يحفظه شخص تثق به بدلاً منك.", "Required for emergency exit. Choose 4 to 8 digits, ideally kept by someone you trust instead of you."))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(8) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            }
        },
        confirmButton = { Button(onClick = { onSave(pin) }, enabled = pin.length >= 4) { Text(L.tr("حفظ", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun AppPickerDialog(
    title: String,
    initial: Set<String>,
    onSave: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    // تحميل قائمة التطبيقات خارج الخيط الرئيسي حتى لا تتجمد الواجهة
    val apps by produceState(initialValue = emptyList<com.focuslock.app.core.AppInfo>()) {
        value = withContext(Dispatchers.Default) { Apps.launchable(ctx) }
    }
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val shown = remember(query, apps) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$title (${selected.size})",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) }
                    Button(onClick = { onSave(selected) }) { Text(L.tr("حفظ", "Save")) }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(L.tr("بحث", "Search")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.pkg }) { app ->
                        val on = app.pkg in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected = if (on) selected - app.pkg else selected + app.pkg }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.pkg, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, modifier = Modifier.weight(1f))
                            Checkbox(
                                checked = on,
                                onCheckedChange = { selected = if (on) selected - app.pkg else selected + app.pkg }
                            )
                        }
                    }
                }
            }
        }
    }
}


// ---------------- قفل الصلاة ----------------

private fun cityLabel(st: AppSettings): String = when {
    st.prayerCity.isEmpty() -> L.tr("اختر المدينة", "Choose a city")
    st.prayerCity == "@gps" -> L.tr("موقعي (تقريبي)", "My location (approx.)")
    else -> Cities.ALL.firstOrNull { it.ar == st.prayerCity }?.name ?: st.prayerCity
}

@android.annotation.SuppressLint("MissingPermission")
private fun lastKnownLocation(ctx: Context): Location? {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    var best: Location? = null
    for (p in lm.getProviders(true)) {
        try {
            val l = lm.getLastKnownLocation(p)
            if (l != null && (best == null || l.time > best.time)) best = l
        } catch (e: SecurityException) { /* تجاهل */ }
    }
    return best
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PrayerSection(st: AppSettings, save: (AppSettings) -> Unit) {
    val ctx = LocalContext.current
    var cityDialog by remember { mutableStateOf(false) }
    val located = st.prayerLat != 0.0 || st.prayerLng != 0.0
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.US) }
    val dateFmt = remember { SimpleDateFormat("d/M", Locale.US) }
    val times = remember(st.prayerLat, st.prayerLng, st.prayerMethod, st.prayerAdjust) {
        if (located) PrayerScheduler.timesFor(st, 0) else null
    }
    val now = System.currentTimeMillis()
    val paused = st.prayerPauseUntil > now

    fun pauseDays(n: Int) {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, n)
        save(st.copy(prayerPauseUntil = c.timeInMillis))
    }

    SectionCard {
        SectionTitle(L.tr("قفل الصلاة", "Prayer Lock"))
        SwitchRow(
            L.tr("تفعيل قفل الصلاة", "Enable Prayer Lock"),
            L.tr(
                "يقفل الهاتف عند دخول وقت الصلاة. اختياري، والمواقيت تُحسب داخل التطبيق بلا إنترنت.",
                "Locks the phone at prayer time. Optional; times are calculated inside the app with no internet."
            ),
            st.prayerOn
        ) {
            save(st.copy(prayerOn = it))
            if (it && !located) cityDialog = true
        }
        if (st.prayerOn) {
            Spacer(Modifier.height(4.dp))
            OutlinedButton(onClick = { cityDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text(L.tr("المدينة: ", "City: ") + cityLabel(st))
            }
            if (!located) {
                Text(
                    L.tr("اختر مدينتك ليعمل القفل.", "Choose your city so the lock can work."),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(L.tr("طريقة الحساب", "Calculation method"), fontWeight = FontWeight.Bold)
            PrayerTimes.METHODS.forEach { m ->
                RadioRow(st.prayerMethod == m.key, L.tr(m.ar, m.en), "") { save(st.copy(prayerMethod = m.key)) }
            }

            // ---- الصلوات: لكل صلاة مفتاح تشغيل ومدة قفل خاصة ----
            Spacer(Modifier.height(10.dp))
            Text(L.tr("الصلوات", "Prayers"), fontWeight = FontWeight.Bold)
            Text(
                L.tr("فعّل القفل للصلوات التي تريدها، وحدّد مدة كل صلاة.", "Turn the lock on for the prayers you want and set each one's duration."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            PrayerScheduler.KEYS.forEachIndexed { i, key ->
                val on = key in st.prayerSet
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(PrayerScheduler.name(i), fontWeight = FontWeight.Bold)
                        if (times != null) {
                            Text(
                                timeFmt.format(Date(times[i])),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        if (on) L.tr("يقفل الهاتف", "Locks phone") else L.tr("بلا قفل", "No lock"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(8.dp))
                    val tick = rememberTick()
                    Switch(
                        checked = on,
                        onCheckedChange = {
                            tick()
                            save(st.copy(prayerSet = if (on) st.prayerSet - key else st.prayerSet + key))
                        }
                    )
                }
                if (on) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 15, 20).forEach { m ->
                            ChipOption(st.prayerDuration(key) == m, fmtMin(m)) {
                                save(st.copy(prayerDurations = st.prayerDurations + (key to m)))
                            }
                        }
                    }
                }
            }
            if (times == null && located) {
                Text(
                    L.tr("تعذّر حساب المواقيت لهذا الموقع بهذه الطريقة. جرّب طريقة أخرى.", "Could not calculate times for this location with this method. Try another method."),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // ---- التأجيل والتنبيه والضبط ----
            Spacer(Modifier.height(10.dp))
            Stepper(
                L.tr("عدد التأجيلات لكل صلاة", "Snoozes per prayer"),
                if (st.prayerSnoozeMax == 0) L.tr("بلا تأجيل: يبدأ القفل مباشرة", "No snooze: lock starts right away")
                else L.tr("حتى ${st.prayerSnoozeMax} (5 أو 10 دقائق لكل تأجيل)", "Up to ${st.prayerSnoozeMax} (5 or 10 min each)"),
                { save(st.copy(prayerSnoozeMax = (st.prayerSnoozeMax - 1).coerceAtLeast(0))) },
                { save(st.copy(prayerSnoozeMax = (st.prayerSnoozeMax + 1).coerceAtMost(3))) }
            )
            Text(
                L.tr(
                    "عند دخول الوقت يصلك إشعار: ابدأ القفل أو أجّل. إن تجاهلته يبقى هاتفك مفتوحاً، وبعد آخر تأجيل يبدأ القفل تلقائياً. لا يتجاوز التأجيل نهاية وقت الصلاة.",
                    "At prayer time you get a notification: lock now or snooze. If you ignore it the phone stays open; after the last snooze the lock starts automatically. Snoozing never goes past the end of the prayer time."
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Stepper(
                L.tr("تنبيه قبل دخول الوقت", "Heads-up before prayer time"),
                if (st.prayerWarnMin == 0) L.tr("بلا تنبيه", "Off") else L.tr("قبل ${st.prayerWarnMin} دقائق", "${st.prayerWarnMin} min before"),
                { save(st.copy(prayerWarnMin = (st.prayerWarnMin - 5).coerceAtLeast(0))) },
                { save(st.copy(prayerWarnMin = (st.prayerWarnMin + 5).coerceAtMost(15))) }
            )
            Stepper(
                L.tr("ضبط المواقيت بالدقائق", "Adjust times (minutes)"),
                (if (st.prayerAdjust > 0) "+" else "") + st.prayerAdjust,
                { save(st.copy(prayerAdjust = (st.prayerAdjust - 1).coerceAtLeast(-10))) },
                { save(st.copy(prayerAdjust = (st.prayerAdjust + 1).coerceAtMost(10))) }
            )

            // ---- إيقاف مؤقت ----
            Spacer(Modifier.height(10.dp))
            Text(L.tr("إيقاف مؤقت", "Pause"), fontWeight = FontWeight.Bold)
            Text(
                if (paused) L.tr("موقوف حتى ${dateFmt.format(Date(st.prayerPauseUntil))}", "Paused until ${dateFmt.format(Date(st.prayerPauseUntil))}")
                else L.tr("قفل الصلاة يعمل حالياً.", "Prayer Lock is currently active."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipOption(false, L.tr("اليوم", "Today")) { pauseDays(1) }
                ChipOption(false, L.tr("3 أيام", "3 days")) { pauseDays(3) }
                ChipOption(false, L.tr("أسبوع", "A week")) { pauseDays(7) }
                if (paused) ChipOption(false, L.tr("استئناف الآن", "Resume now")) { save(st.copy(prayerPauseUntil = 0L)) }
            }

            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {
                    val ok = SessionManager.startPrayer(ctx, L.tr("(اختبار)", "(test)"), 1)
                    if (!ok) {
                        Toast.makeText(ctx, L.tr("هناك جلسة جارية الآن.", "A session is already running."), Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(L.tr("جرّب القفل الآن (دقيقة واحدة)", "Test the lock now (1 minute)")) }
        }
    }

    if (cityDialog) {
        CityDialog(
            onPick = { name, lat, lng ->
                save(st.copy(prayerCity = name, prayerLat = lat, prayerLng = lng))
                cityDialog = false
            },
            onDismiss = { cityDialog = false }
        )
    }
}

@Composable
private fun CityDialog(onPick: (String, Double, Double) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = remember(query) {
        val q = query.trim()
        if (q.isEmpty()) Cities.ALL
        else Cities.ALL.filter { it.ar.contains(q) || it.en.contains(q, ignoreCase = true) }
    }

    fun useLocation() {
        val l = lastKnownLocation(ctx)
        if (l != null) {
            onPick("@gps", l.latitude, l.longitude)
        } else {
            Toast.makeText(
                ctx,
                L.tr("تعذّر تحديد موقعك. اختر مدينة من القائمة.", "Could not get your location. Pick a city from the list."),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) useLocation()
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        L.tr("اختر مدينتك", "Choose your city"),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) }
                }
                Button(
                    onClick = {
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED
                        ) useLocation() else permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) { Text(L.tr("استخدم موقعي التقريبي", "Use my approximate location")) }
                Text(
                    L.tr("الموقع يبقى على هاتفك ولا يُرسل لأي جهة.", "Your location stays on your phone and is never sent anywhere."),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(L.tr("ابحث عن مدينة", "Search a city")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.ar }) { c ->
                        Text(
                            c.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(c.ar, c.lat, c.lng) }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                        )
                    }
                }
            }
        }
    }
}
