package com.focuslock.app.core

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.focuslock.app.data.AppSettings
import com.focuslock.app.data.Snooze
import com.focuslock.app.data.Store
import java.util.Calendar
import kotlin.math.abs

/**
 * يجدول قفل الصلاة: يُضبط دائماً منبّه واحد فقط للحدث القادم (تنبيه قبل الصلاة أو دخول الوقت)،
 * وبعد كل حدث يُحسب الذي يليه، فتتحدّث المواقيت يومياً تلقائياً وتبقى الجدولة سليمة بعد الإقلاع.
 *
 * عند دخول الوقت: إن كان التأجيل مفعّلاً يظهر إشعار (ابدأ الآن / تأجيل 5 / تأجيل 10)؛ تجاهله يترك الهاتف مفتوحاً.
 * وبعد استنفاد آخر تأجيل يبدأ القفل تلقائياً. التأجيل لا يتجاوز نهاية وقت الصلاة.
 */
object PrayerScheduler {
    const val ACTION_FIRE = "com.focuslock.app.PRAYER_FIRE"
    const val ACTION_ACT = "com.focuslock.app.PRAYER_ACT"
    const val ACTION_SNOOZE = "com.focuslock.app.PRAYER_SNOOZE"
    const val ACT_START = 0
    const val ACT_SNOOZE5 = 1
    const val ACT_SNOOZE10 = 2
    private const val RC = 301
    private const val RC_SNOOZE = 302
    private const val RC_ACT = 310
    val KEYS = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")

    fun name(idx: Int): String = when (idx) {
        0 -> L.tr("الفجر", "Fajr")
        1 -> L.tr("الظهر", "Dhuhr")
        2 -> L.tr("العصر", "Asr")
        3 -> L.tr("المغرب", "Maghrib")
        else -> L.tr("العشاء", "Isha")
    }

    private fun ready(st: AppSettings) =
        st.prayerOn && !(st.prayerLat == 0.0 && st.prayerLng == 0.0)

    /** مواقيت اليوم (اليوم + [dayOffset]): الصلوات الخمس 0..4 والشروق 5، أو null. */
    fun timesFor(st: AppSettings, dayOffset: Int): LongArray? =
        PrayerTimes.forDay(
            st.prayerLat, st.prayerLng, PrayerTimes.method(st.prayerMethod), st.prayerAdjust, dayOffset
        )

    private fun paused(st: AppSettings, startMs: Long) = startMs < st.prayerPauseUntil

    private fun durationMs(st: AppSettings, idx: Int) = st.prayerDuration(KEYS[idx]) * 60_000L

    /** نهاية وقت الصلاة: الفجر للشروق، الظهر للعصر، العصر للمغرب، المغرب للعشاء، العشاء لمنتصف الليل. */
    private fun windowEnd(st: AppSettings, idx: Int, startMs: Long): Long {
        for (off in -1..1) {
            val t = timesFor(st, off) ?: continue
            if (t[idx] != startMs) continue
            return when (idx) {
                0 -> t[5]
                1 -> t[2]
                2 -> t[3]
                3 -> t[4]
                else -> {
                    val c = Calendar.getInstance()
                    c.timeInMillis = startMs
                    c.set(Calendar.HOUR_OF_DAY, 0)
                    c.set(Calendar.MINUTE, 0)
                    c.set(Calendar.SECOND, 0)
                    c.set(Calendar.MILLISECOND, 0)
                    c.add(Calendar.DAY_OF_YEAR, 1)
                    c.timeInMillis
                }
            }
        }
        return startMs + durationMs(st, idx)
    }

    private fun cancel(ctx: Context) {
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC, ACTION_FIRE))
    }

    private fun cancelSnoozeAlarm(ctx: Context) {
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_SNOOZE, ACTION_SNOOZE))
    }

    fun actionPi(ctx: Context, act: Int, idx: Int, startMs: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, RC_ACT + act,
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ACT)
                .putExtra("act", act).putExtra("idx", idx).putExtra("start", startMs),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** يعيد جدولة الحدث القادم. [catchUp]: إن كنا داخل نافذة صلاة لم تُعالَج (بعد إقلاع/قتل التطبيق) نكمل المعالجة. */
    fun reschedule(ctx: Context, catchUp: Boolean = false) {
        cancel(ctx)
        cancelSnoozeAlarm(ctx)
        val st = Store.settingsFlow.value
        if (!ready(st)) {
            Store.setSnooze(null)
            Notifier.cancelPrayerDecision(ctx)
            return
        }
        val now = System.currentTimeMillis()

        // تأجيل جارٍ: أعد ضبط منبّهه (أو أكمله إن فات وقته أثناء إيقاف الجهاز)
        val sn = Store.snooze()
        if (sn != null && (paused(st, sn.start) || KEYS[sn.idx] !in st.prayerSet)) {
            Store.setSnooze(null)
            Notifier.cancelPrayerDecision(ctx)
        } else if (sn != null && sn.at > 0L) {
            if (sn.at > now + 1000L) {
                Alarms.set(ctx, sn.at, Alarms.broadcast(ctx, RC_SNOOZE, ACTION_SNOOZE, sn.idx.toLong()))
            } else {
                onSnoozeEnd(ctx)
            }
        }

        if (catchUp && Store.session == null) {
            for (off in -1..0) {
                val t = timesFor(st, off) ?: continue
                for (i in KEYS.indices) {
                    if (KEYS[i] !in st.prayerSet) continue
                    val start = t[i]
                    if (paused(st, start)) continue
                    if (now >= start && now < start + durationMs(st, i) && start > Store.prayerLast()) {
                        Store.setPrayerLast(start)
                        beginDecision(ctx, st, i, start)
                    }
                }
            }
        }

        // الحدث التالي: (الوقت، الفهرس×10 + النوع: 0 تنبيه قبلي، 1 دخول الوقت)
        var bestTime = Long.MAX_VALUE
        var bestId = -1L
        for (off in 0..2) {
            val t = timesFor(st, off) ?: continue
            for (i in KEYS.indices) {
                if (KEYS[i] !in st.prayerSet) continue
                val start = t[i]
                if (paused(st, start)) continue
                if (st.prayerWarnMin > 0) {
                    val w = start - st.prayerWarnMin * 60_000L
                    if (w > now + 1000L && w < bestTime) {
                        bestTime = w
                        bestId = i * 10L
                    }
                }
                if (start > now + 1000L && start < bestTime) {
                    bestTime = start
                    bestId = i * 10L + 1L
                }
            }
        }
        if (bestId >= 0) {
            Alarms.set(ctx, bestTime, Alarms.broadcast(ctx, RC, ACTION_FIRE, bestId))
        }
    }

    /** وقت بدء الصلاة [idx] الأقرب للحظة الحالية (أمس/اليوم/غداً). */
    private fun nearestStart(st: AppSettings, idx: Int): Long? {
        val now = System.currentTimeMillis()
        var best: Long? = null
        for (off in -1..1) {
            val t = timesFor(st, off) ?: continue
            val s = t[idx]
            if (best == null || abs(s - now) < abs(best - now)) best = s
        }
        return best
    }

    fun onFire(ctx: Context, id: Long) {
        val st = Store.settingsFlow.value
        if (id >= 0 && ready(st)) {
            val idx = (id / 10).toInt().coerceIn(0, 4)
            val type = (id % 10).toInt()
            if (KEYS[idx] in st.prayerSet) {
                val start = nearestStart(st, idx)
                if (start != null && !paused(st, start)) {
                    if (type == 0) {
                        Notifier.showPrayerWarn(ctx, name(idx), st.prayerWarnMin)
                        Alerts.warnAlert(ctx)
                    } else {
                        onStart(ctx, st, idx, start)
                    }
                }
            }
        }
        reschedule(ctx)
    }

    private fun onStart(ctx: Context, st: AppSettings, idx: Int, startMs: Long) {
        if (System.currentTimeMillis() >= startMs + durationMs(st, idx) || startMs <= Store.prayerLast()) return
        Store.setPrayerLast(startMs)
        val s = Store.session
        if (s == null) {
            beginDecision(ctx, st, idx, startMs)
        } else if (!s.prayer) {
            // لا قفل ثانٍ: نبقي الجلسة ونمدّ قفلها ليشمل الصلاة
            SessionManager.extendForPrayer(ctx, startMs + durationMs(st, idx))
        }
    }

    /** دخل الوقت والهاتف حرّ: بلا تأجيل يبدأ القفل مباشرة، وإلا يظهر إشعار الاختيار. */
    private fun beginDecision(ctx: Context, st: AppSettings, idx: Int, startMs: Long) {
        cancelSnoozeAlarm(ctx)
        Store.setSnooze(Snooze(startMs, idx, 0, 0L))
        if (st.prayerSnoozeMax <= 0) {
            engage(ctx, st, idx)
        } else {
            showDecision(ctx, st, idx, startMs, 0)
        }
    }

    private fun showDecision(ctx: Context, st: AppSettings, idx: Int, startMs: Long, used: Int) {
        val left = (st.prayerSnoozeMax - used).coerceAtLeast(0)
        val now = System.currentTimeMillis()
        val end = windowEnd(st, idx, startMs)
        val options = if (left > 0) listOf(5, 10).filter { now + it * 60_000L <= end - 60_000L } else emptyList()
        Notifier.showPrayerDecision(ctx, name(idx), idx, startMs, left, options)
        Alerts.endAlert(ctx)
    }

    /** يبدأ القفل فعلاً (من الآن): جلسة صلاة جديدة، أو تمديد جلسة عادية بدأت في الأثناء. */
    private fun engage(ctx: Context, st: AppSettings, idx: Int) {
        Store.setSnooze(null)
        Notifier.cancelPrayerDecision(ctx)
        val now = System.currentTimeMillis()
        val minutes = st.prayerDuration(KEYS[idx])
        val s = Store.session
        if (s == null) {
            SessionManager.startPrayer(ctx, name(idx), minutes, now)
        } else if (!s.prayer) {
            SessionManager.extendForPrayer(ctx, now + minutes * 60_000L)
        }
    }

    /** ضغط المستخدم أحد أزرار الإشعار. */
    fun onAction(ctx: Context, intent: Intent) {
        val st = Store.settingsFlow.value
        val act = intent.getIntExtra("act", ACT_START)
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 4)
        val start = intent.getLongExtra("start", 0L)
        val cur = Store.snooze()
        if (cur == null || cur.start != start || paused(st, start) ||
            System.currentTimeMillis() >= windowEnd(st, idx, start)
        ) {
            Notifier.cancelPrayerDecision(ctx)   // إشعار قديم: لا شيء يُنفَّذ
            return
        }
        if (act == ACT_START) {
            engage(ctx, st, idx)
            return
        }
        val used = (Store.snooze()?.takeIf { it.start == start }?.used ?: 0)
        if (used >= st.prayerSnoozeMax) {
            engage(ctx, st, idx)
            return
        }
        val minutes = if (act == ACT_SNOOZE5) 5 else 10
        val at = System.currentTimeMillis() + minutes * 60_000L
        Store.setSnooze(Snooze(start, idx, used + 1, at))
        Notifier.cancelPrayerDecision(ctx)
        Alarms.set(ctx, at, Alarms.broadcast(ctx, RC_SNOOZE, ACTION_SNOOZE, idx.toLong()))
    }

    /** انتهت مهلة التأجيل: بقيت تأجيلات ← اسأل مجدداً، وإلا يبدأ القفل تلقائياً. */
    fun onSnoozeEnd(ctx: Context) {
        val st = Store.settingsFlow.value
        val sn = Store.snooze() ?: return
        if (sn.at == 0L) return
        if (!ready(st) || KEYS[sn.idx] !in st.prayerSet || paused(st, sn.start)) {
            Store.setSnooze(null)
            Notifier.cancelPrayerDecision(ctx)
            return
        }
        Store.setSnooze(sn.copy(at = 0L))
        if (sn.used >= st.prayerSnoozeMax) {
            engage(ctx, st, sn.idx)
        } else {
            showDecision(ctx, st, sn.idx, sn.start, sn.used)
        }
    }
}
