package com.focuslock.app.core

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focuslock.app.R
import com.focuslock.app.data.Segment
import com.focuslock.app.data.Session
import com.focuslock.app.ui.LockActivity
import com.focuslock.app.ui.MainActivity

@SuppressLint("MissingPermission")
object Notifier {
    private const val CH_SESSION = "session"
    private const val CH_ALERT = "alert"
    private const val ID_ONGOING = 1
    private const val ID_ALERT = 2
    private const val ID_TAMPER = 3
    private const val ID_PRAYER = 4

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CH_SESSION, L.tr("الجلسة الجارية", "Current session"),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        // الصوت والاهتزاز تتولاهما Alerts (ويمكن إيقافهما من الإعدادات)
        val alert = NotificationChannel(
            CH_ALERT, L.tr("تنبيهات التركيز", "Focus alerts"), NotificationManager.IMPORTANCE_HIGH
        )
        alert.setSound(null, null)
        alert.enableVibration(false)
        nm.createNotificationChannel(alert)
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) { /* لا إذن إشعارات */ }
    }

    private fun target(ctx: Context, s: Session?): PendingIntent {
        val cls = if (s?.lockActive == true) LockActivity::class.java else MainActivity::class.java
        return PendingIntent.getActivity(
            ctx, 11,
            Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showOngoing(ctx: Context, s: Session) {
        val onBreak = s.segment == Segment.BREAK
        val text = when {
            s.prayer -> L.tr("ضع هاتفك وأدِّ صلاتك", "Put your phone down and pray")
            onBreak -> L.tr("استرح قليلاً — سيعود التركيز تلقائياً", "Take a break — focus resumes automatically")
            s.lockActive -> L.tr("الهاتف مقفل حتى انتهاء الوقت", "Phone is locked until time is up")
            else -> s.tasks.firstOrNull()?.text ?: ""
        }
        val title = when {
            onBreak -> L.tr("استراحة", "Break")
            s.title.isNotBlank() -> s.title
            else -> L.tr("جلسة تركيز جارية", "Focus session in progress")
        }
        val n = NotificationCompat.Builder(ctx, CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(title)
            .setContentText(text)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(s.endMs)
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ONGOING, n)
    }

    fun showWarn(ctx: Context, s: Session) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("تبقّت دقيقتان", "2 minutes left"))
            .setContentText(L.tr("استعد لإنهاء مهامك", "Get ready to wrap up your tasks"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    /** وقت الصلاة: ابدأ القفل الآن أو أجّل (إن بقيت تأجيلات ويتّسع وقت الصلاة). تجاهله لا يقفل الهاتف. */
    fun showPrayerDecision(ctx: Context, name: String, idx: Int, startMs: Long, left: Int, snoozeOptions: List<Int>) {
        val b = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("حان وقت صلاة $name", "It is time for $name prayer"))
            .setContentText(
                if (snoozeOptions.isEmpty()) L.tr("هل تريد قفل الهاتف الآن؟", "Lock the phone now?")
                else L.tr("هل تريد قفل الهاتف الآن؟ (التأجيلات المتبقية: $left)", "Lock the phone now? (snoozes left: $left)")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60_000L)
            .setContentIntent(PrayerScheduler.actionPi(ctx, PrayerScheduler.ACT_START, idx, startMs))
            .addAction(0, L.tr("ابدأ القفل الآن", "Lock now"),
                PrayerScheduler.actionPi(ctx, PrayerScheduler.ACT_START, idx, startMs))
        for (min in snoozeOptions) {
            val act = if (min == 5) PrayerScheduler.ACT_SNOOZE5 else PrayerScheduler.ACT_SNOOZE10
            b.addAction(0, L.tr("تأجيل $min د", "Snooze $min m"), PrayerScheduler.actionPi(ctx, act, idx, startMs))
        }
        post(ctx, ID_PRAYER, b.build())
    }

    fun cancelPrayerDecision(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID_PRAYER)
    }

    /** تنبيه قبل بدء قفل الصلاة. */
    fun showPrayerWarn(ctx: Context, name: String, minutes: Int) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("اقترب وقت صلاة $name", "$name prayer is near"))
            .setContentText(
                L.tr(
                    "بعد $minutes دقائق يبدأ قفل الصلاة. أنهِ ما بيدك.",
                    "Prayer lock starts in $minutes min. Wrap up what you are doing."
                )
            )
            .setAutoCancel(true)
            .setContentIntent(target(ctx, null))
            .build()
        post(ctx, ID_ALERT, n)
    }

    /** بداية استراحة بومودورو. */
    fun showBreakStart(ctx: Context, s: Session) {
        val min = ((s.endMs - s.segStartMs) / 60_000L).toInt()
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("وقت الاستراحة", "Break time"))
            .setContentText(L.tr("استرح $min دقيقة — تم فتح الهاتف مؤقتاً", "Rest for $min min — phone is unlocked for now"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    /** عودة التركيز بعد الاستراحة. */
    fun showFocusResume(ctx: Context, s: Session) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("عُد للتركيز", "Back to focus"))
            .setContentText(L.tr("الدورة ${s.cycle + 1} من ${s.pomo?.cycles ?: 1}", "Round ${s.cycle + 1} of ${s.pomo?.cycles ?: 1}"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showAsk(ctx: Context, s: Session) {
        val pi = target(ctx, s)
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("انتهى الوقت", "Time is up"))
            .setContentText(L.tr("هل أكملت مهامك؟ اضغط للإجابة", "Did you finish your tasks? Tap to answer"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(false)
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showTamper(ctx: Context) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("تم إيقاف خدمة القفل", "Lock service was turned off"))
            .setContentText(
                L.tr(
                    "أعد تفعيلها من إعدادات إمكانية الوصول لمتابعة جلستك",
                    "Re-enable it in Accessibility settings to continue your session"
                )
            )
            .setAutoCancel(true)
            .setContentIntent(target(ctx, null))
            .build()
        post(ctx, ID_TAMPER, n)
    }

    fun cancelSession(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_ONGOING)
        nm.cancel(ID_ALERT)
    }
}
