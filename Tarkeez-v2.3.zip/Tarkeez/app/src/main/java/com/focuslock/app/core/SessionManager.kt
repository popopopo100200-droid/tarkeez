package com.focuslock.app.core

import android.content.Context
import android.content.Intent
import com.focuslock.app.data.HistoryItem
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Pomo
import com.focuslock.app.data.Segment
import com.focuslock.app.data.Template
import com.focuslock.app.data.Result
import com.focuslock.app.data.Session
import com.focuslock.app.data.Store
import com.focuslock.app.data.TaskItem
import com.focuslock.app.ui.LockActivity

/** كل منطق دورة حياة الجلسة: بدء، تنبيه، سؤال النهاية، تمديد، إنهاء. */
object SessionManager {
    const val ACTION_END = "com.focuslock.app.SESSION_END"
    const val ACTION_WARN = "com.focuslock.app.SESSION_WARN"
    private const val RC_END = 101
    private const val RC_WARN = 102

    fun canExtend(s: Session): Boolean {
        val cap = Store.settingsFlow.value.maxExtensions
        return cap <= 0 || s.extensions < cap
    }

    fun start(
        ctx: Context,
        tasks: List<String>,
        minutes: Int,
        locked: Boolean,
        title: String = "",
        note: String = "",
        pomo: Pomo? = null
    ): Boolean {
        if (Store.session != null || tasks.isEmpty()) return false
        val now = System.currentTimeMillis()
        // في بومودورو المدة الكلية = مجموع فترات التركيز، وينتهي المقطع الأول بعد فترة تركيز واحدة
        val firstMin = pomo?.focusMin ?: minutes
        val total = if (pomo != null) pomo.focusMin * pomo.cycles else minutes
        val s = Session(
            id = now,
            tasks = tasks.map { TaskItem(it) },
            plannedMin = total,
            startMs = now,
            endMs = now + firstMin * 60_000L,
            locked = locked,
            title = title,
            note = note,
            pomo = pomo,
            segment = Segment.FOCUS,
            cycle = 0,
            segStartMs = now
        )
        Store.putSession(s)
        Store.putLast(Template(0L, title, tasks, minutes, locked, pomo))
        armAlarms(ctx, s)
        Notifier.showOngoing(ctx, s)
        Dnd.apply(ctx)
        return true
    }

    fun armAlarms(ctx: Context, s: Session) {
        Alarms.set(ctx, s.endMs, Alarms.broadcast(ctx, RC_END, ACTION_END))
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
        val warnAt = s.endMs - 2 * 60_000L
        if (Store.settingsFlow.value.warnBeforeEnd &&
            s.phase == Phase.RUNNING &&
            s.segment == Segment.FOCUS &&
            !s.prayer &&
            warnAt > System.currentTimeMillis() + 30_000L
        ) {
            Alarms.set(ctx, warnAt, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
        }
    }

    private fun cancelAlarms(ctx: Context) {
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_END, ACTION_END))
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
    }

    /** شبكة أمان: إن تأخر المنبّه ننتقل لمرحلة السؤال عند أول فرصة. */
    fun checkExpiry(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING && System.currentTimeMillis() >= s.endMs) onEnd(ctx)
    }

    fun onWarn(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING && s.segment == Segment.FOCUS) {
            Notifier.showWarn(ctx, s)
            Alerts.warnAlert(ctx)
        }
    }

    fun onEnd(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.ASKING) return
        // منبّه قديم بعد تمديد الوقت
        if (System.currentTimeMillis() < s.endMs - 1500L) return
        if (s.prayer) {
            endPrayer(ctx)
            return
        }
        val p = s.pomo
        val now = System.currentTimeMillis()
        if (p != null && s.segment == Segment.FOCUS && s.cycle < p.cycles - 1) {
            // نهاية دورة تركيز ← استراحة (طويلة بعد كل 4 دورات)
            val brk = if ((s.cycle + 1) % 4 == 0) p.longBreakMin else p.breakMin
            val n = s.copy(segment = Segment.BREAK, segStartMs = now, endMs = now + brk * 60_000L)
            Store.putSession(n)
            armAlarms(ctx, n)
            Notifier.showOngoing(ctx, n)
            Notifier.showBreakStart(ctx, n)
            Alerts.endAlert(ctx)
            Dnd.restore(ctx)
            return
        }
        if (p != null && s.segment == Segment.BREAK) {
            // نهاية الاستراحة ← دورة تركيز جديدة
            val brkMin = ((s.endMs - s.segStartMs) / 60_000L).toInt()
            val n = s.copy(
                segment = Segment.FOCUS, cycle = s.cycle + 1, segStartMs = now,
                endMs = now + p.focusMin * 60_000L, breakDoneMin = s.breakDoneMin + brkMin
            )
            Store.putSession(n)
            armAlarms(ctx, n)
            Notifier.showOngoing(ctx, n)
            Notifier.showFocusResume(ctx, n)
            Alerts.endAlert(ctx)
            Dnd.apply(ctx)
            if (n.locked) launchLock(ctx)
            return
        }
        // نهاية الجلسة ← سؤال "هل أنجزت؟"
        val n = s.copy(phase = Phase.ASKING)
        Store.putSession(n)
        Notifier.showAsk(ctx, n)
        Alerts.endAlert(ctx)
        if (n.locked) launchLock(ctx)
    }

    fun launchLock(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(ctx, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (e: Exception) { /* قد يمنعه النظام من الخلفية؛ الإشعار وخدمة القفل يتكفّلان */ }
    }

    fun toggleTask(index: Int) {
        val s = Store.session ?: return
        if (index !in s.tasks.indices) return
        val t = s.tasks.toMutableList()
        t[index] = t[index].copy(done = !t[index].done)
        Store.putSession(s.copy(tasks = t))
    }

    // ----------- إجابات سؤال النهاية -----------

    /** "نعم، أنجزت مهامي" */
    fun answerYes(ctx: Context) = finish(ctx, Result.COMPLETED, markAllDone = true)

    /** "ما أنجزته يكفي" */
    fun answerEnough(ctx: Context) = finish(ctx, Result.PARTIAL)

    /** خروج طارئ أو إلغاء: يُسجَّل كجلسة ملغاة ويكسر السلسلة. */
    fun abandon(ctx: Context) = finish(ctx, Result.ABANDONED)

    /** إنهاء مبكر عند إنجاز كل المهام. */
    fun finishEarly(ctx: Context) = finish(ctx, Result.COMPLETED, markAllDone = true)

    /** "لا، لم أكمل" ثم تحديد مدة إضافية. يعيد false إن بلغنا الحد الأقصى للتمديد. */
    fun extend(ctx: Context, minutes: Int, lock: Boolean? = null): Boolean {
        val s = Store.session ?: return false
        if (!canExtend(s)) return false
        val now = System.currentTimeMillis()
        val newLocked = lock ?: s.locked
        val n = s.copy(
            phase = Phase.RUNNING,
            endMs = now + minutes * 60_000L,
            extensions = s.extensions + 1,
            extraMin = s.extraMin + minutes,
            locked = newLocked,
            segment = Segment.FOCUS,
            segStartMs = now,
            cycle = s.pomo?.let { it.cycles - 1 } ?: s.cycle
        )
        Store.putSession(n)
        armAlarms(ctx, n)
        Notifier.showOngoing(ctx, n)
        Dnd.apply(ctx)
        if (newLocked && !s.locked) launchLock(ctx)
        return true
    }

    private fun finish(ctx: Context, result: Result, markAllDone: Boolean = false) {
        val s = Store.session ?: return
        if (s.prayer) {
            teardownPrayer(ctx)
            return
        }
        val now = System.currentTimeMillis()
        val tasks = if (markAllDone) s.tasks.map { it.copy(done = true) } else s.tasks
        val endEff = minOf(now, s.endMs)
        // نخصم وقت الاستراحات من وقت التركيز الفعلي
        val curBreakMs = if (s.segment == Segment.BREAK) (now - s.segStartMs).coerceAtLeast(0L) else 0L
        val totalMs = (now - s.startMs).coerceAtLeast(0L)
        val focusMs = if (s.pomo != null) {
            totalMs - s.breakDoneMin * 60_000L - curBreakMs
        } else {
            endEff - s.startMs
        }
        val actualMin = (focusMs / 60_000L).toInt().coerceAtLeast(0)
        val item = HistoryItem(
            id = s.id, startMs = s.startMs, endMs = now,
            plannedMin = s.plannedMin, actualMin = actualMin,
            tasksTotal = tasks.size, tasksDone = tasks.count { it.done },
            result = result, locked = s.locked, extensions = s.extensions,
            title = s.title, attempts = s.attempts
        )
        Store.addHistory(item)
        Store.putSession(null)
        cancelAlarms(ctx)
        Notifier.cancelSession(ctx)
        Dnd.restore(ctx)
        if (result != Result.ABANDONED) Store.summaryFlow.value = item
    }

    // ----------- قفل الصلاة -----------

    /** يبدأ قفل صلاة تلقائياً؛ ينتهي عند [startMs] + [minutes] دقيقة. */
    fun startPrayer(ctx: Context, name: String, minutes: Int, startMs: Long = System.currentTimeMillis()): Boolean {
        if (Store.session != null) return false
        val end = startMs + minutes * 60_000L
        if (System.currentTimeMillis() >= end) return false
        val s = Session(
            id = startMs,
            tasks = listOf(TaskItem(name)),
            plannedMin = minutes,
            startMs = startMs,
            endMs = end,
            locked = true,
            title = L.tr("صلاة $name", "$name prayer"),
            prayer = true,
            segStartMs = startMs
        )
        Store.putSession(s)
        armAlarms(ctx, s)
        Notifier.showOngoing(ctx, s)
        Dnd.apply(ctx)
        launchLock(ctx)
        return true
    }

    /** جلسة عادية جارية: نبقيها ونمدّ القفل (ونفعّله إن لم يكن مفعّلاً) ليشمل وقت الصلاة. */
    fun extendForPrayer(ctx: Context, prayerEndMs: Long) {
        val s = Store.session ?: return
        if (s.prayer || s.pomo != null || s.phase != Phase.RUNNING) return
        val n = s.copy(locked = true, endMs = maxOf(s.endMs, prayerEndMs))
        Store.putSession(n)
        armAlarms(ctx, n)
        Notifier.showOngoing(ctx, n)
        Dnd.apply(ctx)
        launchLock(ctx)
    }

    private fun endPrayer(ctx: Context) {
        teardownPrayer(ctx)
        Alerts.endAlert(ctx)
    }

    /** إنهاء صامت لقفل الصلاة: لا سجل ولا ملخص ولا كسر لسلسلة الأيام. */
    private fun teardownPrayer(ctx: Context) {
        Store.putSession(null)
        cancelAlarms(ctx)
        Notifier.cancelSession(ctx)
        Dnd.restore(ctx)
    }

    /** بعد إعادة تشغيل الجهاز أو تحديث التطبيق. */
    fun restore(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING && System.currentTimeMillis() >= s.endMs) {
            onEnd(ctx)
            return
        }
        armAlarms(ctx, s)
        if (s.phase == Phase.ASKING) Notifier.showAsk(ctx, s) else Notifier.showOngoing(ctx, s)
    }
}
