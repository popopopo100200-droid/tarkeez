package com.focuslock.app.core

import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.focuslock.app.data.Store

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        when (intent.action) {
            SessionManager.ACTION_END -> SessionManager.onEnd(context)
            SessionManager.ACTION_WARN -> SessionManager.onWarn(context)
            PrayerScheduler.ACTION_ACT -> PrayerScheduler.onAction(context, intent)
            PrayerScheduler.ACTION_SNOOZE -> PrayerScheduler.onSnoozeEnd(context)
            PrayerScheduler.ACTION_FIRE ->
                PrayerScheduler.onFire(context, intent.getLongExtra(Alarms.EXTRA_ID, -1L))
            ScheduleManager.ACTION_FIRE ->
                ScheduleManager.onFire(context, intent.getLongExtra(Alarms.EXTRA_ID, -1L))
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        Notifier.createChannels(context)
        SessionManager.restore(context)
        Dnd.syncAfterBoot(context)
        ScheduleManager.rescheduleAll(context)
        PrayerScheduler.reschedule(context, catchUp = true)
    }
}

/** مستقبل مدير الجهاز: يُستخدم فقط لمنع حذف التطبيق (اختياري). */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        L.tr("إلغاء الحماية يسمح بحذف تطبيق Tarkeez.", "Removing protection allows Tarkeez to be uninstalled.")
}
