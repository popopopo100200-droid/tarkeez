package com.focuslock.app

import android.app.Application
import com.focuslock.app.core.Notifier
import com.focuslock.app.core.PrayerScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import com.focuslock.app.data.Store

class FocusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.createChannels(this)
        com.focuslock.app.core.Dnd.syncAfterBoot(this)
        // قفل الصلاة: إعادة الجدولة عند بدء التطبيق، ثم عند أي تغيير في إعداداته
        PrayerScheduler.reschedule(this, catchUp = true)
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            Store.settingsFlow
                .map { s ->
                    listOf(s.prayerOn, s.prayerLat, s.prayerLng, s.prayerMethod, s.prayerMinutes,
                        s.prayerSet, s.prayerWarnMin, s.prayerAdjust, s.prayerSnoozeMax,
                        s.prayerDurations, s.prayerPauseUntil)
                }
                .distinctUntilChanged()
                .drop(1)
                .collect { PrayerScheduler.reschedule(this@FocusApp) }
        }
    }
}
