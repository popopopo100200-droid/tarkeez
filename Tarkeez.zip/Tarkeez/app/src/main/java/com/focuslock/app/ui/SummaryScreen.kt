package com.focuslock.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focuslock.app.core.L
import com.focuslock.app.data.HistoryItem
import com.focuslock.app.data.Result
import com.focuslock.app.data.Stats
import com.focuslock.app.data.Store

/** شاشة ملخص تظهر بعد انتهاء كل جلسة. */
@Composable
fun SummaryScreen(item: HistoryItem, onClose: () -> Unit) {
    val history by Store.historyFlow.collectAsState()
    val settings by Store.settingsFlow.collectAsState()
    val streak = remember(history) { Stats.streak(history) }
    val today = remember(history) { Stats.todayMinutes(history) }
    val tick = rememberTick()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            Icon(
                if (item.result == Result.COMPLETED) Icons.Rounded.CheckCircle else Icons.Rounded.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(84.dp)
            )
            Text(
                if (item.result == Result.COMPLETED) L.tr("أحسنت! أنجزت جلستك", "Well done! Session complete")
                else L.tr("انتهت الجلسة", "Session finished"),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            if (item.title.isNotBlank()) {
                Text(item.title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            SectionCard {
                SumRow(L.tr("وقت التركيز", "Focus time"), fmtMin(item.actualMin))
                SumRow(L.tr("المهام المنجزة", "Tasks done"), "${item.tasksDone}/${item.tasksTotal}")
                if (item.locked) {
                    SumRow(L.tr("محاولات فتح تطبيقات محجوبة", "Blocked app attempts"), "${item.attempts}")
                }
                if (item.extensions > 0) {
                    SumRow(L.tr("مرات التمديد", "Extensions"), "${item.extensions}")
                }
                SumRow(
                    L.tr("اليوم", "Today"),
                    "${fmtMin(today)} / ${fmtMin(settings.dailyGoalMin)}"
                )
                SumRow(L.tr("أيام متتالية", "Day streak"), "$streak")
            }
            Button(
                onClick = { tick(); onClose() },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(L.tr("تم", "Done")) }
        }
    }
}

@Composable
private fun SumRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
