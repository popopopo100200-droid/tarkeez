package com.focuslock.app

import android.app.Application
import com.focuslock.app.core.Notifier
import com.focuslock.app.data.Store

class FocusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.createChannels(this)
        com.focuslock.app.core.Dnd.syncAfterBoot(this)
    }
}
