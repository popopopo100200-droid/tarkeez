package com.focuslock.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val LightScheme = lightColorScheme(
    primary = Color(0xFF4F46E5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF), onPrimaryContainer = Color(0xFF1E1B6E),
    secondary = Color(0xFF0D9488), onSecondary = Color.White,
    secondaryContainer = Color(0xFFCCFBF1), onSecondaryContainer = Color(0xFF042F2E),
    background = Color(0xFFF7F7FB), onBackground = Color(0xFF14142B),
    surface = Color.White, onSurface = Color(0xFF14142B),
    surfaceVariant = Color(0xFFEDEDF5), onSurfaceVariant = Color(0xFF5B5B76),
    error = Color(0xFFDC2626), onError = Color.White,
    errorContainer = Color(0xFFFEE2E2), onErrorContainer = Color(0xFF7F1D1D),
    outline = Color(0xFFCBCBDD)
)

val DarkScheme = darkColorScheme(
    primary = Color(0xFF8B8BFF), onPrimary = Color(0xFF14123F),
    primaryContainer = Color(0xFF2B2A6B), onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = Color(0xFF2DD4BF), onSecondary = Color(0xFF042F2E),
    secondaryContainer = Color(0xFF0F3D3A), onSecondaryContainer = Color(0xFFCCFBF1),
    background = Color(0xFF0E0F1F), onBackground = Color(0xFFEDEDFA),
    surface = Color(0xFF171830), onSurface = Color(0xFFEDEDFA),
    surfaceVariant = Color(0xFF22233F), onSurfaceVariant = Color(0xFFA9A9C6),
    error = Color(0xFFF87171), onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF5B1A1A), onErrorContainer = Color(0xFFFEE2E2),
    outline = Color(0xFF3A3B5E)
)

/** التطبيق عربي فقط، لذا نفرض الاتجاه من اليمين لليسار دائماً. */
@Composable
fun TarkeezTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}

/** شاشة القفل داكنة دائماً. */
@Composable
fun TarkeezDarkTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = DarkScheme, typography = Typography(), content = content)
    }
}
