package com.focuslock.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimeInput
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.focuslock.app.core.Perms
import com.focuslock.app.core.ScheduleManager
import com.focuslock.app.data.Schedule
import com.focuslock.app.data.Store

/** (قيمة Calendar.DAY_OF_WEEK، الاسم) بترتيب الأسبوع العربي */
private val DAYS = listOf(
    7 to "السبت", 1 to "الأحد", 2 to "الاثنين", 3 to "الثلاثاء",
    4 to "الأربعاء", 5 to "الخميس", 6 to "الجمعة"
)

@Composable
fun SchedulesScreen() {
    val schedules by Store.schedulesFlow.collectAsState()
    var adding by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("الجدولة", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    "جلسات تبدأ تلقائياً في أيام وأوقات تحددها",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(onClick = { adding = true }) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("إضافة")
            }
        }

        if (schedules.isEmpty()) {
            SectionCard {
                Text(
                    "لا توجد جلسات مجدولة بعد. مثال: «مذاكرة» كل يوم من 8 إلى 10 مساءً مع قفل الهاتف.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        schedules.forEach { s ->
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        val dayNames = DAYS.filter { it.first in s.days }.joinToString("، ") { it.second }
                        Text(
                            "$dayNames · %02d:%02d · ${fmtMin(s.durationMin)}".format(s.hour, s.minute),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            if (s.locked) "مع قفل الهاتف" else "بدون قفل",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Switch(checked = s.enabled, onCheckedChange = { ScheduleManager.setEnabled(ctx, s, it) })
                    IconButton(onClick = { ScheduleManager.delete(ctx, s) }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "حذف")
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }

    if (adding) {
        ScheduleDialog(
            onDismiss = { adding = false },
            onSave = {
                ScheduleManager.save(ctx, it)
                adding = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun ScheduleDialog(onDismiss: () -> Unit, onSave: (Schedule) -> Unit) {
    val ctx = LocalContext.current
    val a11yOk = remember { Perms.accessibilityEnabled(ctx) }
    var title by remember { mutableStateOf("") }
    var days by remember { mutableStateOf(setOf<Int>()) }
    var minutes by remember { mutableIntStateOf(60) }
    var locked by remember { mutableStateOf(a11yOk) }
    val time = rememberTimePickerState(initialHour = 20, initialMinute = 0, is24Hour = true)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("جلسة مجدولة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم المهمة (مثال: مذاكرة)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("الأيام", fontWeight = FontWeight.Bold)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    DAYS.forEach { (d, name) ->
                        FilterChip(
                            selected = d in days,
                            onClick = { days = if (d in days) days - d else days + d },
                            label = { Text(name) }
                        )
                    }
                }
                Text("وقت البدء", fontWeight = FontWeight.Bold)
                TimeInput(state = time)
                Text("المدة", fontWeight = FontWeight.Bold)
                DurationPicker(minutes) { minutes = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = locked, onCheckedChange = { locked = it }, enabled = a11yOk)
                    Spacer(Modifier.width(8.dp))
                    Text(if (a11yOk) "قفل الهاتف أثناء الجلسة" else "القفل يحتاج تفعيل خدمة القفل أولاً")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = title.isNotBlank() && days.isNotEmpty(),
                        onClick = {
                            onSave(
                                Schedule(
                                    id = Store.nextId(),
                                    title = title.trim(),
                                    days = days,
                                    hour = time.hour,
                                    minute = time.minute,
                                    durationMin = minutes,
                                    locked = locked && a11yOk
                                )
                            )
                        }
                    ) { Text("حفظ") }
                }
            }
        }
    }
}
