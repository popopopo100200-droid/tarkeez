package com.focuslock.app.core

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.focuslock.app.data.Store
import com.focuslock.app.ui.LockActivity

/**
 * خدمة إمكانية الوصول: تراقب تغيّر النافذة الأمامية فقط (دون قراءة أي محتوى)،
 * وعند فتح تطبيق محجوب أثناء جلسة مقفلة تعيد المستخدم للرئيسية وتعرض شاشة القفل.
 */
class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastBlockAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        SessionManager.checkExpiry(this)
        val s = Store.session ?: return
        if (!s.lockActive) return
        if (Guard.shouldBlock(this, pkg, Store.settingsFlow.value)) {
            block(pkg)
        }
    }

    private fun block(pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlockAt < 700L) return
        lastBlockAt = now
        if (pkg != packageName && !Guard.isHome(this, pkg)) Store.recordAttempt(pkg)
        // إن كنا على الشاشة الرئيسية أصلاً فلا داعي لضغط "رئيسية"، نعرض شاشة القفل فقط.
        if (!Guard.isHome(this, pkg)) performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            try {
                startActivity(
                    Intent(this, LockActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                )
            } catch (e: Exception) { /* تجاهل */ }
        }, 150L)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        // أُوقفت الخدمة أثناء جلسة مقفلة: نبّه المستخدم
        if (Store.session?.lockActive == true) Notifier.showTamper(this)
        return super.onUnbind(intent)
    }
}
