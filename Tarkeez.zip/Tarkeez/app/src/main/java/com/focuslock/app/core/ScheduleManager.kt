package com.focuslock.app.core

import android.content.Context
import com.focuslock.app.data.Schedule
import com.focuslock.app.data.Store
import java.util.Calendar

/** جلسات تبدأ تلقائياً في أيام وأوقات محددة. */
object ScheduleManager {
    const val ACTION_FIRE = "com.focuslock.app.SCHEDULE_FIRE"

    private fun rc(id: Long): Int = 10_000 + (id % 50_000L).toInt()

    fun save(ctx: Context, s: Schedule) {
        val list = Store.schedulesFlow.value.toMutableList()
        val i = list.indexOfFirst { it.id == s.id }
        if (i >= 0) list[i] = s else list.add(s)
        Store.putSchedules(list)
        arm(ctx, s)
    }

    fun delete(ctx: Context, s: Schedule) {
        cancel(ctx, s.id)
        Store.putSchedules(Store.schedulesFlow.value.filter { it.id != s.id })
    }

    fun setEnabled(ctx: Context, s: Schedule, on: Boolean) = save(ctx, s.copy(enabled = on))

    fun rescheduleAll(ctx: Context) {
        Store.schedulesFlow.value.forEach { arm(ctx, it) }
    }

    private fun cancel(ctx: Context, id: Long) {
        Alarms.cancel(ctx, Alarms.broadcast(ctx, rc(id), ACTION_FIRE, id))
    }

    fun arm(ctx: Context, s: Schedule) {
        cancel(ctx, s.id)
        if (!s.enabled) return
        val t = nextTrigger(s, System.currentTimeMillis()) ?: return
        Alarms.set(ctx, t, Alarms.broadcast(ctx, rc(s.id), ACTION_FIRE, s.id))
    }

    fun nextTrigger(s: Schedule, from: Long): Long? {
        if (s.days.isEmpty()) return null
        val cal = Calendar.getInstance()
        for (add in 0..7) {
            cal.timeInMillis = from
            cal.add(Calendar.DAY_OF_YEAR, add)
            cal.set(Calendar.HOUR_OF_DAY, s.hour)
            cal.set(Calendar.MINUTE, s.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.get(Calendar.DAY_OF_WEEK) in s.days && cal.timeInMillis > from) {
                return cal.timeInMillis
            }
        }
        return null
    }

    fun onFire(ctx: Context, id: Long) {
        val s = Store.schedulesFlow.value.firstOrNull { it.id == id } ?: return
        if (s.enabled && Store.session == null) {
            if (SessionManager.start(ctx, listOf(s.title), s.durationMin, s.locked) && s.locked) {
                SessionManager.launchLock(ctx)
            }
        }
        arm(ctx, s) // حدّد الموعد التالي دائماً
    }
}
