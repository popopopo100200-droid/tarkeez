package com.focuslock.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.core.Apps
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.LockMode
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Store
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** شاشة القفل: العدّ التنازلي، المهام، التطبيقات المسموحة، وسؤال النهاية. */
class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TarkeezDarkTheme {
                LockScreen(onExit = { finishAndRemoveTask() })
            }
        }
    }
}

@Composable
private fun LockScreen(onExit: () -> Unit) {
    val ctx = LocalContext.current
    val session by Store.sessionFlow.collectAsState()
    val settings by Store.settingsFlow.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showExit by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            SessionManager.checkExpiry(ctx)
            delay(500)
        }
    }

    val s = session
    val inactive = s == null || !s.locked
    LaunchedEffect(inactive) { if (inactive) onExit() }

    // لا رجوع من شاشة القفل
    BackHandler(enabled = true) { }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF0E0F1F))))
    ) {
        if (s != null && s.locked) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(Modifier.height(8.dp))
                Icon(
                    Icons.Rounded.Lock, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp)
                )

                if (s.phase == Phase.ASKING) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(20.dp))
                            .padding(18.dp)
                    ) { AskFlow(s) }
                } else {
                    val total = (s.endMs - s.startMs).coerceAtLeast(1L)
                    val remaining = (s.endMs - now).coerceAtLeast(0L)
                    val progress = (1f - remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                    val endText = SimpleDateFormat("HH:mm", Locale.US).format(Date(s.endMs))

                    Text(
                        if (s.title.isNotBlank()) s.title else "الهاتف مقفل للتركيز",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFFA9A9C6)
                    )
                    Text(
                        fmtClock(remaining),
                        fontSize = 68.sp, fontWeight = FontWeight.Bold,
                        color = Color.White, textAlign = TextAlign.Center
                    )
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = Color.White.copy(alpha = 0.12f)
                    )
                    Text("ينتهي عند $endText", color = Color(0xFFA9A9C6))

                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(20.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("مهامك", style = MaterialTheme.typography.titleSmall, color = Color(0xFFA9A9C6))
                            TaskChecklist(s.tasks) { SessionManager.toggleTask(it) }
                            if (s.note.isNotBlank()) {
                                Text(
                                    s.note,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFA9A9C6),
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }

                    if (settings.lockMode == LockMode.ALL_EXCEPT_ALLOWED && settings.allowedApps.isNotEmpty()) {
                        AllowedApps(settings.allowedApps.toList())
                    }

                    if (settings.earlyFinish && s.tasks.all { it.done }) {
                        Button(
                            onClick = { SessionManager.finishEarly(ctx) },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("أنجزت كل شيء، أنهِ الجلسة")
                        }
                    }

                    TextButton(onClick = { showExit = true }) {
                        Text("خروج طارئ", color = Color(0xFFF87171))
                    }
                }
            }
        }
    }

    if (showExit) {
        ExitDialog(
            delaySec = settings.exitDelaySec,
            pin = settings.pin,
            onConfirm = {
                showExit = false
                SessionManager.abandon(ctx)
            },
            onDismiss = { showExit = false }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AllowedApps(pkgs: List<String>) {
    val ctx = LocalContext.current
    val launchable = remember(pkgs) {
        pkgs.filter { ctx.packageManager.getLaunchIntentForPackage(it) != null }
    }
    if (launchable.isEmpty()) return
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("تطبيقات مسموحة", style = MaterialTheme.typography.titleSmall, color = Color(0xFFA9A9C6))
        FlowRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            launchable.forEach { pkg ->
                Column(
                    Modifier
                        .width(72.dp)
                        .clickable {
                            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
                                ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    AppIcon(pkg, 44.dp)
                    Text(
                        Apps.label(ctx, pkg), color = Color.White, fontSize = 11.sp,
                        maxLines = 1, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/** الخروج الطارئ: انتظار إجباري (+ رمز PIN إن وُجد). يُسجَّل كجلسة ملغاة. */
@Composable
private fun ExitDialog(delaySec: Int, pin: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var left by remember { mutableIntStateOf(delaySec) }
    var typed by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }
    val pinOk = pin.isEmpty() || typed == pin
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خروج طارئ؟") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("سيُسجَّل ذلك كجلسة ملغاة ويكسر سلسلة أيامك المتتالية.")
                if (pin.isNotEmpty()) {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it },
                        label = { Text("رمز PIN") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                }
                if (left > 0) Text("يمكنك التأكيد بعد $left ثانية", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = left <= 0 && pinOk,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) { Text("تأكيد الخروج") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("العودة للتركيز") } }
    )
}
