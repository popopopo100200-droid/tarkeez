package com.focuslock.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focuslock.app.core.Apps
import com.focuslock.app.core.L
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.LockMode
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Store
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** شاشة القفل: حلقة العدّ التنازلي، سبب التركيز، المهام، شريط التطبيقات المسموحة، وسؤال النهاية. */
class LockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighRefreshRate()
        setContent {
            TarkeezDarkTheme {
                LockScreen(onExit = {
                    // عند انتهاء الجلسة نعرض ملخصها داخل التطبيق
                    if (Store.summaryFlow.value != null) {
                        try {
                            startActivity(
                                Intent(this, MainActivity::class.java)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            )
                        } catch (e: Exception) { /* تجاهل */ }
                    }
                    finishAndRemoveTask()
                })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        requestHighRefreshRate()
    }
}

private val Dim = Color(0xFFA9A9C6)

@Composable
private fun LockScreen(onExit: () -> Unit) {
    val ctx = LocalContext.current
    val session by Store.sessionFlow.collectAsState()
    val settings by Store.settingsFlow.collectAsState()
    var showExit by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            SessionManager.checkExpiry(ctx)
            delay(500)
        }
    }

    val s = session
    val inactive = s == null || !s.lockActive
    LaunchedEffect(inactive) { if (inactive) onExit() }

    // لا رجوع من شاشة القفل
    BackHandler(enabled = true) { }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (s != null && s.lockActive) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Spacer(Modifier.height(4.dp))
                    Icon(
                        Icons.Rounded.Lock, contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp)
                    )

                    if (s.phase == Phase.ASKING) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(22.dp))
                                .padding(18.dp)
                        ) { AskFlow(s) }
                    } else {
                        RunningPart(s)
                    }
                }

                // الشريط السفلي: التطبيقات المسموحة + خروج طارئ خافت
                Column(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (s.phase == Phase.RUNNING &&
                        settings.lockMode == LockMode.ALL_EXCEPT_ALLOWED &&
                        settings.allowedApps.isNotEmpty()
                    ) {
                        AllowedDock(settings.allowedApps.toList())
                    }
                    TextButton(onClick = { showExit = true }, modifier = Modifier.alpha(0.55f)) {
                        Text(L.tr("خروج طارئ", "Emergency exit"), color = Color(0xFFF87171), fontSize = 12.sp)
                    }
                }
            }
        }
    }

    if (showExit) {
        ExitDialog(
            delaySec = settings.exitDelaySec,
            pin = settings.pin,
            onConfirm = {
                showExit = false
                SessionManager.abandon(ctx)
            },
            onDismiss = { showExit = false }
        )
    }
}

@Composable
private fun RunningPart(s: com.focuslock.app.data.Session) {
    val ctx = LocalContext.current
    val settings by Store.settingsFlow.collectAsState()
    val nowState = rememberNow(500L)
    val segTotal = (s.endMs - s.segStartMs).coerceAtLeast(1L)
    val endText = remember(s.endMs) { SimpleDateFormat("HH:mm", Locale.US).format(Date(s.endMs)) }
    val pomo = s.pomo

    Text(
        if (s.title.isNotBlank()) s.title else L.tr("الهاتف مقفل للتركيز", "Phone is locked for focus"),
        style = MaterialTheme.typography.titleMedium,
        color = Dim
    )

    ProgressRing(
        progress = { 1f - ((s.endMs - nowState.value).coerceAtLeast(0L).toFloat() / segTotal) },
        modifier = Modifier.size(260.dp),
        stroke = 14.dp,
        color = MaterialTheme.colorScheme.primary,
        track = Color.White.copy(alpha = 0.10f)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ClockText(
                s.endMs,
                MaterialTheme.typography.displayLarge.copy(fontSize = 54.sp, fontWeight = FontWeight.Bold),
                Color.White
            )
            Text(L.tr("ينتهي عند $endText", "Ends at $endText"), color = Dim, fontSize = 13.sp)
            if (pomo != null) {
                Text(
                    L.tr("الدورة ${s.cycle + 1}/${pomo.cycles}", "Round ${s.cycle + 1}/${pomo.cycles}"),
                    color = Dim, fontSize = 13.sp
                )
            }
        }
    }

    if (s.note.isNotBlank()) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Text(L.tr("لماذا أركّز؟", "Why am I focusing?"), style = MaterialTheme.typography.labelMedium, color = Dim)
            Text(s.note, color = Color.White, style = MaterialTheme.typography.bodyLarge)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp))
            .padding(14.dp)
    ) {
        Text(L.tr("مهامك", "Your tasks"), style = MaterialTheme.typography.titleSmall, color = Dim)
        TaskChecklist(s.tasks) { SessionManager.toggleTask(it) }
    }

    if (settings.earlyFinish && s.tasks.all { it.done }) {
        Button(
            onClick = { SessionManager.finishEarly(ctx) },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Rounded.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(L.tr("أنجزت كل شيء، أنهِ الجلسة", "All done, end the session"))
        }
    }
}

/** شريط سفلي بالتطبيقات المسموحة (يُمرَّر أفقياً إن كثرت). */
@Composable
private fun AllowedDock(pkgs: List<String>) {
    val ctx = LocalContext.current
    val launchable = remember(pkgs) {
        pkgs.filter { ctx.packageManager.getLaunchIntentForPackage(it) != null }
    }
    if (launchable.isEmpty()) return
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(26.dp))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        launchable.forEach { pkg ->
            Column(
                Modifier
                    .width(64.dp)
                    .clickable {
                        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
                            ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppIcon(pkg, 42.dp)
                Text(
                    Apps.label(ctx, pkg), color = Color.White, fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** الخروج الطارئ: انتظار إجباري (+ رمز PIN إن وُجد). يُسجَّل كجلسة ملغاة. */
@Composable
private fun ExitDialog(delaySec: Int, pin: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var left by remember { mutableIntStateOf(delaySec) }
    var typed by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
    }
    val pinOk = pin.isEmpty() || typed == pin
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("خروج طارئ؟", "Emergency exit?")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    L.tr(
                        "سيُسجَّل ذلك كجلسة ملغاة ويكسر سلسلة أيامك المتتالية.",
                        "This will be recorded as an abandoned session and break your streak."
                    )
                )
                if (pin.isNotEmpty()) {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it },
                        label = { Text(L.tr("رمز PIN", "PIN")) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                }
                if (left > 0) {
                    Text(
                        L.tr("يمكنك التأكيد بعد $left ثانية", "You can confirm in $left s"),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = left <= 0 && pinOk,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) { Text(L.tr("تأكيد الخروج", "Confirm exit")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L.tr("العودة للتركيز", "Back to focus")) } }
    )
}
