package com.focuslock.app.core

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.focuslock.app.data.Store
import com.focuslock.app.ui.MainActivity

/** بلاطة في الإعدادات السريعة: تبدأ آخر جلسة بلمسة واحدة (أو تفتح التطبيق إن كانت جلسة جارية). */
class QuickTile : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        Store.init(this)
        val t = qsTile ?: return
        t.state = if (Store.session != null) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }

    override fun onClick() {
        super.onClick()
        val i = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_QUICK)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 21, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
