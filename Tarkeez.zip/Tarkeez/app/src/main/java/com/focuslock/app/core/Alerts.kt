package com.focuslock.app.core

import android.content.Context
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import com.focuslock.app.data.Store

/** صوت واهتزاز عند انتهاء الوقت (يُحترم وضع الصامت في الهاتف). */
object Alerts {
    private fun vibrate(ctx: Context, pattern: LongArray) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) { /* تجاهل */ }
    }

    fun endAlert(ctx: Context) {
        if (!Store.settingsFlow.value.endAlert) return
        vibrate(ctx, longArrayOf(0, 500, 250, 500, 250, 800))
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(ctx, uri)?.play()
        } catch (e: Exception) { /* تجاهل */ }
    }

    fun warnAlert(ctx: Context) {
        if (!Store.settingsFlow.value.endAlert) return
        vibrate(ctx, longArrayOf(0, 300))
    }
}
