package com.focuslock.app.core

import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telecom.TelecomManager

data class AppInfo(val pkg: String, val label: String)

object Apps {
    /** كل التطبيقات القابلة للتشغيل (عدا هذا التطبيق) مرتبة بالاسم. */
    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun label(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    /** التطبيقات المسموحة افتراضياً: الاتصال، الرسائل، جهات الاتصال، الخرائط (إن وُجدت). */
    fun defaultAllowed(ctx: Context): Set<String> {
        val out = mutableSetOf<String>()
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            tm?.defaultDialerPackage?.let { out += it }
        } catch (e: Exception) { /* تجاهل */ }
        try {
            Telephony.Sms.getDefaultSmsPackage(ctx)?.let { out += it }
        } catch (e: Exception) { /* تجاهل */ }
        val installed = launchable(ctx).map { it.pkg }.toSet()
        listOf(
            "com.google.android.contacts", "com.android.contacts", "com.samsung.android.contacts",
            "com.google.android.apps.maps", "com.android.emergency"
        ).filter { it in installed }.forEach { out += it }
        return out
    }
}
