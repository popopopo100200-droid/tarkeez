package com.focuslock.app.core

import android.app.NotificationManager
import android.content.Context
import com.focuslock.app.data.Store

/** وضع عدم الإزعاج أثناء الجلسة (اختياري)، مع حفظ الحالة السابقة واستعادتها. */
object Dnd {
    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun granted(ctx: Context): Boolean = try {
        nm(ctx).isNotificationPolicyAccessGranted
    } catch (e: Exception) {
        false
    }

    fun apply(ctx: Context) {
        if (!Store.settingsFlow.value.dnd || !granted(ctx)) return
        try {
            val n = nm(ctx)
            if (Store.dndPrev() == -1) Store.setDndPrev(n.currentInterruptionFilter)
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } catch (e: Exception) { /* تجاهل */ }
    }

    fun restore(ctx: Context) {
        val prev = Store.dndPrev()
        if (prev == -1) return
        try {
            if (granted(ctx)) {
                val f = if (prev == NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
                    NotificationManager.INTERRUPTION_FILTER_ALL
                } else {
                    prev
                }
                nm(ctx).setInterruptionFilter(f)
            }
        } catch (e: Exception) { /* تجاهل */ }
        Store.setDndPrev(-1)
    }

    /** عند الإقلاع/بدء التطبيق: طبّق إن كانت جلسة تركيز جارية وإلا استعد الحالة السابقة. */
    fun syncAfterBoot(ctx: Context) {
        val s = Store.session
        if (s != null && s.segment == com.focuslock.app.data.Segment.FOCUS) apply(ctx) else restore(ctx)
    }
}
