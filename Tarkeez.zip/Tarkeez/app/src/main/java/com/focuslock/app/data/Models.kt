package com.focuslock.app.data

data class TaskItem(val text: String, val done: Boolean = false)

enum class Phase { RUNNING, ASKING }

data class Session(
    val id: Long,
    val tasks: List<TaskItem>,
    val plannedMin: Int,
    val startMs: Long,
    val endMs: Long,
    val locked: Boolean,
    val phase: Phase = Phase.RUNNING,
    val extensions: Int = 0,
    val extraMin: Int = 0
)

enum class Result { COMPLETED, PARTIAL, ABANDONED }

data class HistoryItem(
    val id: Long,
    val startMs: Long,
    val endMs: Long,
    val plannedMin: Int,
    val actualMin: Int,
    val tasksTotal: Int,
    val tasksDone: Int,
    val result: Result,
    val locked: Boolean,
    val extensions: Int
)

/** days: قيم Calendar.DAY_OF_WEEK (الأحد = 1 ... السبت = 7) */
data class Schedule(
    val id: Long,
    val title: String,
    val days: Set<Int>,
    val hour: Int,
    val minute: Int,
    val durationMin: Int,
    val locked: Boolean,
    val enabled: Boolean = true
)

enum class LockMode { ALL_EXCEPT_ALLOWED, ONLY_SELECTED }

data class AppSettings(
    val lockMode: LockMode = LockMode.ALL_EXCEPT_ALLOWED,
    val allowedApps: Set<String> = emptySet(),
    val blockedApps: Set<String> = emptySet(),
    val maxExtensions: Int = 3,
    val exitDelaySec: Int = 30,
    val pin: String = "",
    val earlyFinish: Boolean = false,
    val warnBeforeEnd: Boolean = true,
    val protectSettings: Boolean = true,
    val onboarded: Boolean = false
)
