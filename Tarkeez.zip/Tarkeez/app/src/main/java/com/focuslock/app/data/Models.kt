package com.focuslock.app.data

data class TaskItem(val text: String, val done: Boolean = false)

enum class Phase { RUNNING, ASKING }

/** مقطع بومودورو الحالي: تركيز أو راحة. */
enum class Segment { FOCUS, BREAK }

/** إعدادات بومودورو لجلسة: مدة التركيز والراحة القصيرة والطويلة وعدد دورات التركيز. */
data class Pomo(val focusMin: Int, val breakMin: Int, val longBreakMin: Int, val cycles: Int)

data class Session(
    val id: Long,
    val tasks: List<TaskItem>,
    val plannedMin: Int,
    val startMs: Long,
    val endMs: Long,
    val locked: Boolean,
    val phase: Phase = Phase.RUNNING,
    val extensions: Int = 0,
    val extraMin: Int = 0,
    val title: String = "",
    val note: String = "",
    val pomo: Pomo? = null,
    val segment: Segment = Segment.FOCUS,
    val cycle: Int = 0,
    val segStartMs: Long = 0L,
    val breakDoneMin: Int = 0,
    val attempts: Int = 0
) {
    /** القفل فعّال الآن؟ (لا يكون فعّالاً أثناء راحة بومودورو). */
    val lockActive: Boolean
        get() = locked && (phase == Phase.ASKING || segment == Segment.FOCUS)
}

enum class Result { COMPLETED, PARTIAL, ABANDONED }

data class HistoryItem(
    val id: Long,
    val startMs: Long,
    val endMs: Long,
    val plannedMin: Int,
    val actualMin: Int,
    val tasksTotal: Int,
    val tasksDone: Int,
    val result: Result,
    val locked: Boolean,
    val extensions: Int,
    val title: String = "",
    val attempts: Int = 0
)

/** قالب جلسة محفوظ. يُستخدم أيضاً لحفظ آخر جلسة للبدء السريع. */
data class Template(
    val id: Long,
    val title: String,
    val tasks: List<String>,
    val minutes: Int,
    val locked: Boolean,
    val pomo: Pomo? = null
)

/** days: قيم Calendar.DAY_OF_WEEK (الأحد = 1 ... السبت = 7) */
data class Schedule(
    val id: Long,
    val title: String,
    val days: Set<Int>,
    val hour: Int,
    val minute: Int,
    val durationMin: Int,
    val locked: Boolean,
    val enabled: Boolean = true
)

enum class LockMode { ALL_EXCEPT_ALLOWED, ONLY_SELECTED }

enum class ThemeMode { AUTO, LIGHT, DARK }

data class AppSettings(
    val lockMode: LockMode = LockMode.ALL_EXCEPT_ALLOWED,
    val allowedApps: Set<String> = emptySet(),
    val blockedApps: Set<String> = emptySet(),
    val maxExtensions: Int = 3,
    val exitDelaySec: Int = 30,
    val pin: String = "",
    val earlyFinish: Boolean = false,
    val warnBeforeEnd: Boolean = true,
    val protectSettings: Boolean = true,
    val onboarded: Boolean = false,
    val endAlert: Boolean = true,
    /** "auto" (لغة النظام) أو "ar" أو "en" */
    val language: String = "auto",
    val theme: ThemeMode = ThemeMode.AUTO,
    val dnd: Boolean = false,
    val dailyGoalMin: Int = 120,
    val pomoFocus: Int = 25,
    val pomoBreak: Int = 5,
    val pomoLongBreak: Int = 15,
    val pomoCycles: Int = 4
)
