package com.focuslock.app.core

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.focuslock.app.R
import com.focuslock.app.ui.MainActivity

/** ودجت للشاشة الرئيسية: لمسة واحدة لبدء آخر جلسة. */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val i = Intent(context, MainActivity::class.java)
            .setAction(MainActivity.ACTION_QUICK)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            context, 22, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        for (id in ids) {
            val rv = RemoteViews(context.packageName, R.layout.widget_quick)
            rv.setOnClickPendingIntent(R.id.widget_root, pi)
            manager.updateAppWidget(id, rv)
        }
    }
}
