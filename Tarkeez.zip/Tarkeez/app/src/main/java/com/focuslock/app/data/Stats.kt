package com.focuslock.app.data

import java.util.Calendar

data class DayStat(val label: String, val minutes: Int, val isToday: Boolean)

object Stats {
    private val dayNames = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")

    private fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun addDays(dayStart: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart
        c.add(Calendar.DAY_OF_YEAR, n)
        return c.timeInMillis
    }

    fun todayMinutes(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int {
        val d = startOfDay(now)
        return h.filter { it.result != Result.ABANDONED && startOfDay(it.endMs) == d }.sumOf { it.actualMin }
    }

    /** آخر 7 أيام تنتهي باليوم الحالي. */
    fun lastWeek(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): List<DayStat> {
        val today = startOfDay(now)
        return (6 downTo 0).map { back ->
            val ds = addDays(today, -back)
            val minutes = h.filter { it.result != Result.ABANDONED && startOfDay(it.endMs) == ds }.sumOf { it.actualMin }
            val c = Calendar.getInstance()
            c.timeInMillis = ds
            DayStat(dayNames[c.get(Calendar.DAY_OF_WEEK) - 1], minutes, back == 0)
        }
    }

    fun weekMinutes(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int =
        lastWeek(h, now).sumOf { it.minutes }

    /** أيام متتالية فيها جلسة غير ملغاة. إن لم يكن اليوم فيه جلسة يبدأ العدّ من أمس. */
    fun streak(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int {
        val days = h.filter { it.result != Result.ABANDONED }.map { startOfDay(it.endMs) }.toSet()
        var d = startOfDay(now)
        if (d !in days) d = addDays(d, -1)
        var n = 0
        while (d in days) {
            n++
            d = addDays(d, -1)
        }
        return n
    }

    fun totalTasksDone(h: List<HistoryItem>): Int = h.sumOf { it.tasksDone }

    /** نسبة الجلسات التي انتهت دون تمديد (دقة تقدير الوقت). null إن لم توجد بيانات. */
    fun onTimeRate(h: List<HistoryItem>): Int? {
        val valid = h.filter { it.result != Result.ABANDONED }
        if (valid.isEmpty()) return null
        return valid.count { it.extensions == 0 } * 100 / valid.size
    }

    fun abandonedCount(h: List<HistoryItem>): Int = h.count { it.result == Result.ABANDONED }
}
