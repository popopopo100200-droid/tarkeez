package com.focuslock.app.data

import com.focuslock.app.core.L
import java.util.Calendar

data class DayStat(val label: String, val minutes: Int, val isToday: Boolean)

object Stats {
    private val dayNamesAr = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")
    private val dayNamesEn = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    private fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun addDays(dayStart: Long, n: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = dayStart
        c.add(Calendar.DAY_OF_YEAR, n)
        return c.timeInMillis
    }

    /** دقائق التركيز لكل يوم (بداية اليوم ← دقائق)، دون الجلسات الملغاة. */
    private fun byDay(h: List<HistoryItem>): Map<Long, Int> {
        val m = HashMap<Long, Int>()
        for (it in h) {
            if (it.result == Result.ABANDONED) continue
            val d = startOfDay(it.endMs)
            m[d] = (m[d] ?: 0) + it.actualMin
        }
        return m
    }

    fun todayMinutes(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int =
        byDay(h)[startOfDay(now)] ?: 0

    /** آخر 7 أيام تنتهي باليوم الحالي. */
    fun lastWeek(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): List<DayStat> {
        val m = byDay(h)
        val today = startOfDay(now)
        val names = if (L.isAr()) dayNamesAr else dayNamesEn
        return (6 downTo 0).map { back ->
            val ds = addDays(today, -back)
            val c = Calendar.getInstance()
            c.timeInMillis = ds
            DayStat(names[c.get(Calendar.DAY_OF_WEEK) - 1], m[ds] ?: 0, back == 0)
        }
    }

    fun weekMinutes(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int =
        lastWeek(h, now).sumOf { it.minutes }

    /** مجموع الأيام السبعة التي قبل الأسبوع الحالي (للمقارنة). */
    fun previousWeekMinutes(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int {
        val m = byDay(h)
        val today = startOfDay(now)
        return (7..13).sumOf { back -> m[addDays(today, -back)] ?: 0 }
    }

    /** دقائق كل يوم لآخر [days] يوماً، الأقدم أولاً وآخر عنصر هو اليوم. */
    fun heatmap(h: List<HistoryItem>, days: Int = 35, now: Long = System.currentTimeMillis()): List<Int> {
        val m = byDay(h)
        val today = startOfDay(now)
        return ((days - 1) downTo 0).map { back -> m[addDays(today, -back)] ?: 0 }
    }

    /** أيام متتالية فيها جلسة غير ملغاة. إن لم يكن اليوم فيه جلسة يبدأ العدّ من أمس. */
    fun streak(h: List<HistoryItem>, now: Long = System.currentTimeMillis()): Int {
        val days = h.filter { it.result != Result.ABANDONED }.map { startOfDay(it.endMs) }.toSet()
        var d = startOfDay(now)
        if (d !in days) d = addDays(d, -1)
        var n = 0
        while (d in days) {
            n++
            d = addDays(d, -1)
        }
        return n
    }

    fun totalTasksDone(h: List<HistoryItem>): Int = h.sumOf { it.tasksDone }

    /** نسبة الجلسات التي انتهت دون تمديد (دقة تقدير الوقت). null إن لم توجد بيانات. */
    fun onTimeRate(h: List<HistoryItem>): Int? {
        val valid = h.filter { it.result != Result.ABANDONED }
        if (valid.isEmpty()) return null
        return valid.count { it.extensions == 0 } * 100 / valid.size
    }

    fun abandonedCount(h: List<HistoryItem>): Int = h.count { it.result == Result.ABANDONED }
}
