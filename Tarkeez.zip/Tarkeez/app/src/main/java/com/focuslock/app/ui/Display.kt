package com.focuslock.app.ui

import android.app.Activity
import android.os.Build

/** يطلب من النظام أعلى معدل تحديث تدعمه الشاشة (90/120 هرتز) بدل 60 الافتراضية. */
fun Activity.requestHighRefreshRate() {
    try {
        val d = if (Build.VERSION.SDK_INT >= 30) display else @Suppress("DEPRECATION") windowManager.defaultDisplay
        if (d == null) return
        val cur = d.mode
        val best = d.supportedModes
            .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .maxByOrNull { it.refreshRate } ?: return
        val lp = window.attributes
        lp.preferredDisplayModeId = best.modeId
        window.attributes = lp
    } catch (e: Exception) { /* تجاهل */ }
}
