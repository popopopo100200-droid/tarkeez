package com.focuslock.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.focuslock.app.core.Perms

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { Perms.accessibilityEnabled(ctx) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Text("أهلاً بك في تركيز", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(
                "اكتب مهامك، حدّد الوقت المتوقع، ودع التطبيق يحجب المشتتات حتى تنتهي. " +
                    "نحتاج بعض الأذونات ليعمل القفل بشكل صحيح.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SectionCard { PermissionsPanel() }
            Button(
                onClick = onDone,
                enabled = a11y,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("ابدأ الاستخدام") }
            if (!a11y) {
                Text(
                    "فعّل خدمة القفل أولاً للمتابعة، أو تخطَّ الآن واستخدم الجلسات بدون قفل.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TextButton(onClick = onDone) { Text("تخطي الآن") }
            }
        }
    }
}
