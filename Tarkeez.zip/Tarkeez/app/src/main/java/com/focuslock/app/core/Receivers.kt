package com.focuslock.app.core

import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.focuslock.app.data.Store

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        when (intent.action) {
            SessionManager.ACTION_END -> SessionManager.onEnd(context)
            SessionManager.ACTION_WARN -> SessionManager.onWarn(context)
            ScheduleManager.ACTION_FIRE ->
                ScheduleManager.onFire(context, intent.getLongExtra(Alarms.EXTRA_ID, -1L))
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        Notifier.createChannels(context)
        SessionManager.restore(context)
        ScheduleManager.rescheduleAll(context)
    }
}

/** مستقبل مدير الجهاز: يُستخدم فقط لمنع حذف التطبيق (اختياري). */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "إلغاء الحماية يسمح بحذف تطبيق تركيز."
}
