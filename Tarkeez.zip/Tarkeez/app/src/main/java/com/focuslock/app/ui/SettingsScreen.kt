package com.focuslock.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.produceState
import com.focuslock.app.core.Dnd
import com.focuslock.app.core.L
import com.focuslock.app.data.Pomo
import com.focuslock.app.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.focuslock.app.core.Apps
import com.focuslock.app.data.AppSettings
import com.focuslock.app.data.LockMode
import com.focuslock.app.data.Store

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val st by Store.settingsFlow.collectAsState()
    var picking by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    fun save(n: AppSettings) = Store.saveSettings(n)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle(L.tr("الإعدادات", "Settings"))

        SectionCard {
            SectionTitle(L.tr("المظهر واللغة", "Appearance & language"))
            Text(L.tr("المظهر", "Theme"), fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipOption(st.theme == ThemeMode.AUTO, L.tr("تلقائي", "Auto")) { save(st.copy(theme = ThemeMode.AUTO)) }
                ChipOption(st.theme == ThemeMode.LIGHT, L.tr("فاتح", "Light")) { save(st.copy(theme = ThemeMode.LIGHT)) }
                ChipOption(st.theme == ThemeMode.DARK, L.tr("داكن", "Dark")) { save(st.copy(theme = ThemeMode.DARK)) }
            }
            Spacer(Modifier.height(8.dp))
            Text(L.tr("اللغة", "Language"), fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipOption(st.language == "auto", L.tr("لغة النظام", "System language")) { save(st.copy(language = "auto")) }
                ChipOption(st.language == "ar", "العربية") { save(st.copy(language = "ar")) }
                ChipOption(st.language == "en", "English") { save(st.copy(language = "en")) }
            }
        }

        SectionCard {
            SectionTitle(L.tr("الهدف وبومودورو", "Goal & Pomodoro"))
            Stepper(
                L.tr("هدف التركيز اليومي", "Daily focus goal"), fmtMin(st.dailyGoalMin),
                { save(st.copy(dailyGoalMin = (st.dailyGoalMin - 15).coerceAtLeast(15))) },
                { save(st.copy(dailyGoalMin = (st.dailyGoalMin + 15).coerceAtMost(720))) }
            )
            Spacer(Modifier.height(4.dp))
            Text(
                L.tr("القيم الافتراضية لبومودورو (يمكن تغييرها لكل جلسة):", "Pomodoro defaults (can be changed per session):"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            PomoEditor(Pomo(st.pomoFocus, st.pomoBreak, st.pomoLongBreak, st.pomoCycles)) {
                save(st.copy(pomoFocus = it.focusMin, pomoBreak = it.breakMin, pomoLongBreak = it.longBreakMin, pomoCycles = it.cycles))
            }
        }

        SectionCard {
            SectionTitle(L.tr("وضع القفل", "Lock mode"))
            RadioRow(
                st.lockMode == LockMode.ALL_EXCEPT_ALLOWED,
                L.tr("قفل كامل ما عدا المسموح", "Full lock except allowed apps"),
                L.tr("كل التطبيقات محجوبة عدا التي تختارها (الاتصال والرسائل افتراضياً).", "All apps are blocked except those you choose (calls and messages by default).")
            ) { save(st.copy(lockMode = LockMode.ALL_EXCEPT_ALLOWED)) }
            RadioRow(
                st.lockMode == LockMode.ONLY_SELECTED,
                L.tr("حجب تطبيقات محددة فقط", "Block selected apps only"),
                L.tr("تُحجب التطبيقات التي تختارها وحدها، وبقية الهاتف يعمل.", "Only the apps you choose are blocked; the rest of the phone works.")
            ) { save(st.copy(lockMode = LockMode.ONLY_SELECTED)) }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (st.lockMode == LockMode.ALL_EXCEPT_ALLOWED)
                        L.tr("التطبيقات المسموحة (${st.allowedApps.size})", "Allowed apps (${st.allowedApps.size})")
                    else L.tr("التطبيقات المحجوبة (${st.blockedApps.size})", "Blocked apps (${st.blockedApps.size})")
                )
            }
            Text(
                L.tr("المكالمات والطوارئ ولوحة المفاتيح والشاشة الرئيسية مسموحة دائماً.", "Calls, emergency, keyboard and home screen are always allowed."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard {
            SectionTitle(L.tr("الصرامة والحماية", "Strictness & protection"))
            SwitchRow(
                L.tr("عدم الإزعاج أثناء التركيز", "Do Not Disturb while focusing"),
                L.tr("اختياري: يكتم الإشعارات أثناء الجلسة ثم يعيد حالته السابقة بعدها. يحتاج إذن الوصول لسياسة الإشعارات.",
                    "Optional: silences notifications during a session and restores your previous state afterwards. Needs notification-policy access."),
                st.dnd
            ) {
                save(st.copy(dnd = it))
                if (it && !Dnd.granted(ctx)) {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    } catch (e: Exception) { /* تجاهل */ }
                }
            }
            SwitchRow(
                L.tr("حماية الإعدادات أثناء الجلسة", "Protect Settings during a session"),
                L.tr("حجب تطبيق الإعدادات ومثبّت التطبيقات لمنع تعطيل القفل أو حذف التطبيق.", "Blocks the Settings app and package installer to prevent disabling the lock or uninstalling."),
                st.protectSettings
            ) { save(st.copy(protectSettings = it)) }
            SwitchRow(
                L.tr("السماح بالإنهاء المبكر", "Allow early finish"),
                L.tr("عند إنجاز كل المهام يمكنك إنهاء الجلسة المقفلة قبل انتهاء الوقت.", "When all tasks are done you can end a locked session early."),
                st.earlyFinish
            ) { save(st.copy(earlyFinish = it)) }
            SwitchRow(
                L.tr("تنبيه قبل النهاية بدقيقتين", "Warn 2 minutes before the end"),
                L.tr("إشعار يذكّرك بقرب انتهاء الوقت.", "A notification reminds you time is almost up."),
                st.warnBeforeEnd
            ) { save(st.copy(warnBeforeEnd = it)) }
            SwitchRow(
                L.tr("صوت واهتزاز عند انتهاء الوقت", "Sound & vibration at the end"),
                L.tr("ينبّهك صوتياً واهتزازياً عند النهاية (يحترم وضع الصامت).", "Alerts you with sound and vibration (respects silent mode)."),
                st.endAlert
            ) { save(st.copy(endAlert = it)) }
            Stepper(
                L.tr("انتظار الخروج الطارئ", "Emergency exit wait"),
                L.tr("${st.exitDelaySec} ثانية", "${st.exitDelaySec} s"),
                { save(st.copy(exitDelaySec = (st.exitDelaySec - 10).coerceAtLeast(10))) },
                { save(st.copy(exitDelaySec = (st.exitDelaySec + 10).coerceAtMost(120))) }
            )
            Stepper(
                L.tr("الحد الأقصى للتمديد", "Maximum extensions"),
                if (st.maxExtensions == 0) L.tr("بلا حد", "Unlimited") else L.tr("${st.maxExtensions} مرات", "${st.maxExtensions} times"),
                { save(st.copy(maxExtensions = (st.maxExtensions - 1).coerceAtLeast(0))) },
                { save(st.copy(maxExtensions = (st.maxExtensions + 1).coerceAtMost(10))) }
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(L.tr("رمز PIN للخروج الطارئ", "Emergency-exit PIN"), fontWeight = FontWeight.Bold)
                    Text(
                        if (st.pin.isEmpty()) L.tr("غير مفعّل", "Off") else L.tr("مفعّل", "On"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (st.pin.isNotEmpty()) {
                    TextButton(onClick = { save(st.copy(pin = "")) }) { Text(L.tr("حذف", "Remove")) }
                }
                OutlinedButton(onClick = { pinDialog = true }) {
                    Text(if (st.pin.isEmpty()) L.tr("تعيين", "Set") else L.tr("تغيير", "Change"))
                }
            }
        }

        SectionCard {
            SectionTitle(L.tr("الأذونات والجاهزية", "Permissions & readiness"))
            PermissionsPanel()
        }

        SectionCard {
            Text("Tarkeez 2.0", fontWeight = FontWeight.Bold)
            Text(
                L.tr("كل بياناتك تبقى على هاتفك فقط. التطبيق لا يطلب إذن الإنترنت ولا يرسل أي شيء.",
                    "All your data stays on your phone. The app has no internet permission and sends nothing."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(12.dp))
    }

    if (picking) {
        val isAllowed = st.lockMode == LockMode.ALL_EXCEPT_ALLOWED
        AppPickerDialog(
            title = if (isAllowed) L.tr("التطبيقات المسموحة", "Allowed apps") else L.tr("التطبيقات المحجوبة", "Blocked apps"),
            initial = if (isAllowed) st.allowedApps else st.blockedApps,
            onSave = {
                save(if (isAllowed) st.copy(allowedApps = it) else st.copy(blockedApps = it))
                picking = false
            },
            onDismiss = { picking = false }
        )
    }

    if (pinDialog) {
        PinDialog(
            onSave = { save(st.copy(pin = it)); pinDialog = false },
            onDismiss = { pinDialog = false }
        )
    }
}

@Composable
private fun ChipOption(selected: Boolean, label: String, onClick: () -> Unit) {
    val tick = rememberTick()
    FilterChip(selected = selected, onClick = { tick(); onClick() }, label = { Text(label) })
}

@Composable
private fun RadioRow(selected: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = { tick(); onChange(it) })
    }
}

@Composable
private fun PinDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("رمز PIN", "PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(L.tr("يُطلب عند الخروج الطارئ. اختر رمزاً من 4 إلى 8 أرقام، ويُفضّل أن يحفظه شخص تثق به بدلاً منك.", "Required for emergency exit. Choose 4 to 8 digits, ideally kept by someone you trust instead of you."))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(8) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            }
        },
        confirmButton = { Button(onClick = { onSave(pin) }, enabled = pin.length >= 4) { Text(L.tr("حفظ", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun AppPickerDialog(
    title: String,
    initial: Set<String>,
    onSave: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    // تحميل قائمة التطبيقات خارج الخيط الرئيسي حتى لا تتجمد الواجهة
    val apps by produceState(initialValue = emptyList<com.focuslock.app.core.AppInfo>()) {
        value = withContext(Dispatchers.Default) { Apps.launchable(ctx) }
    }
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val shown = remember(query, apps) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$title (${selected.size})",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) }
                    Button(onClick = { onSave(selected) }) { Text(L.tr("حفظ", "Save")) }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(L.tr("بحث", "Search")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.pkg }) { app ->
                        val on = app.pkg in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected = if (on) selected - app.pkg else selected + app.pkg }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.pkg, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, modifier = Modifier.weight(1f))
                            Checkbox(
                                checked = on,
                                onCheckedChange = { selected = if (on) selected - app.pkg else selected + app.pkg }
                            )
                        }
                    }
                }
            }
        }
    }
}
