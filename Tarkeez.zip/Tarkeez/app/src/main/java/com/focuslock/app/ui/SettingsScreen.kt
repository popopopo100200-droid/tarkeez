package com.focuslock.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.focuslock.app.core.Apps
import com.focuslock.app.data.AppSettings
import com.focuslock.app.data.LockMode
import com.focuslock.app.data.Store

@Composable
fun SettingsScreen() {
    val st by Store.settingsFlow.collectAsState()
    var picking by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    fun save(n: AppSettings) = Store.saveSettings(n)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)

        SectionCard {
            SectionTitle("وضع القفل")
            RadioRow(
                st.lockMode == LockMode.ALL_EXCEPT_ALLOWED,
                "قفل كامل ما عدا المسموح",
                "كل التطبيقات محجوبة عدا التي تختارها (الاتصال والرسائل افتراضياً)."
            ) { save(st.copy(lockMode = LockMode.ALL_EXCEPT_ALLOWED)) }
            RadioRow(
                st.lockMode == LockMode.ONLY_SELECTED,
                "حجب تطبيقات محددة فقط",
                "تُحجب التطبيقات التي تختارها وحدها، وبقية الهاتف يعمل."
            ) { save(st.copy(lockMode = LockMode.ONLY_SELECTED)) }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (st.lockMode == LockMode.ALL_EXCEPT_ALLOWED) "التطبيقات المسموحة (${st.allowedApps.size})"
                    else "التطبيقات المحجوبة (${st.blockedApps.size})"
                )
            }
            Text(
                "المكالمات والطوارئ ولوحة المفاتيح والشاشة الرئيسية مسموحة دائماً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard {
            SectionTitle("الصرامة والحماية")
            SwitchRow(
                "حماية الإعدادات أثناء الجلسة",
                "حجب تطبيق الإعدادات ومثبّت التطبيقات لمنع تعطيل القفل أو حذف التطبيق.",
                st.protectSettings
            ) { save(st.copy(protectSettings = it)) }
            SwitchRow(
                "السماح بالإنهاء المبكر",
                "عند إنجاز كل المهام يمكنك إنهاء الجلسة المقفلة قبل انتهاء الوقت.",
                st.earlyFinish
            ) { save(st.copy(earlyFinish = it)) }
            SwitchRow(
                "تنبيه قبل النهاية بدقيقتين",
                "إشعار يذكّرك بقرب انتهاء الوقت.",
                st.warnBeforeEnd
            ) { save(st.copy(warnBeforeEnd = it)) }
            SwitchRow(
                "صوت واهتزاز عند انتهاء الوقت",
                "ينبّهك صوتياً واهتزازياً عند النهاية (يحترم وضع الصامت).",
                st.endAlert
            ) { save(st.copy(endAlert = it)) }
            StepperRow(
                "انتظار الخروج الطارئ",
                "${st.exitDelaySec} ثانية",
                onMinus = { save(st.copy(exitDelaySec = (st.exitDelaySec - 10).coerceAtLeast(10))) },
                onPlus = { save(st.copy(exitDelaySec = (st.exitDelaySec + 10).coerceAtMost(120))) }
            )
            StepperRow(
                "الحد الأقصى للتمديد",
                if (st.maxExtensions == 0) "بلا حد" else "${st.maxExtensions} مرات",
                onMinus = { save(st.copy(maxExtensions = (st.maxExtensions - 1).coerceAtLeast(0))) },
                onPlus = { save(st.copy(maxExtensions = (st.maxExtensions + 1).coerceAtMost(10))) }
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("رمز PIN للخروج الطارئ", fontWeight = FontWeight.Bold)
                    Text(
                        if (st.pin.isEmpty()) "غير مفعّل" else "مفعّل",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (st.pin.isNotEmpty()) {
                    TextButton(onClick = { save(st.copy(pin = "")) }) { Text("حذف") }
                }
                OutlinedButton(onClick = { pinDialog = true }) {
                    Text(if (st.pin.isEmpty()) "تعيين" else "تغيير")
                }
            }
        }

        SectionCard {
            SectionTitle("الأذونات")
            PermissionsPanel()
        }

        SectionCard {
            Text("تركيز 1.1", fontWeight = FontWeight.Bold)
            Text(
                "كل بياناتك تبقى على هاتفك فقط. التطبيق لا يطلب إذن الإنترنت ولا يرسل أي شيء.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(12.dp))
    }

    if (picking) {
        val isAllowed = st.lockMode == LockMode.ALL_EXCEPT_ALLOWED
        AppPickerDialog(
            title = if (isAllowed) "التطبيقات المسموحة" else "التطبيقات المحجوبة",
            initial = if (isAllowed) st.allowedApps else st.blockedApps,
            onSave = {
                save(if (isAllowed) st.copy(allowedApps = it) else st.copy(blockedApps = it))
                picking = false
            },
            onDismiss = { picking = false }
        )
    }

    if (pinDialog) {
        PinDialog(
            onSave = { save(st.copy(pin = it)); pinDialog = false },
            onDismiss = { pinDialog = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun RadioRow(selected: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StepperRow(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalIconButton(onClick = onMinus) { Icon(Icons.Rounded.Remove, contentDescription = "أنقص") }
        Spacer(Modifier.width(6.dp))
        FilledTonalIconButton(onClick = onPlus) { Icon(Icons.Rounded.Add, contentDescription = "زِد") }
    }
}

@Composable
private fun PinDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("رمز PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("يُطلب عند الخروج الطارئ. اختر رمزاً من 4 إلى 8 أرقام، ويُفضّل أن يحفظه شخص تثق به بدلاً منك.")
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(8) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            }
        },
        confirmButton = { Button(onClick = { onSave(pin) }, enabled = pin.length >= 4) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AppPickerDialog(
    title: String,
    initial: Set<String>,
    onSave: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val apps = remember { Apps.launchable(ctx) }
    var selected by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val shown = remember(query, apps) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$title (${selected.size})",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) { Text("إلغاء") }
                    Button(onClick = { onSave(selected) }) { Text("حفظ") }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("بحث") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(shown, key = { it.pkg }) { app ->
                        val on = app.pkg in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected = if (on) selected - app.pkg else selected + app.pkg }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.pkg, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, modifier = Modifier.weight(1f))
                            Checkbox(
                                checked = on,
                                onCheckedChange = { selected = if (on) selected - app.pkg else selected + app.pkg }
                            )
                        }
                    }
                }
            }
        }
    }
}
