package com.focuslock.app.core

import com.focuslock.app.data.Store
import java.util.Locale

/** لغة التطبيق (عربي/إنجليزي): تلقائي يتبع لغة النظام. */
object L {
    fun isAr(): Boolean = when (Store.settingsFlow.value.language) {
        "ar" -> true
        "en" -> false
        else -> Locale.getDefault().language == "ar"
    }

    fun tr(ar: String, en: String): String = if (isAr()) ar else en
}
