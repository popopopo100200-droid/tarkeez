package com.focuslock.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.focuslock.app.data.Store

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { TarkeezTheme { AppRoot() } }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    val settings by Store.settingsFlow.collectAsState()
    val session by Store.sessionFlow.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    // أثناء جلسة مقفلة لا نسمح بالوصول لإعدادات التطبيق: نحوّل لشاشة القفل.
    LaunchedEffect(session?.id, session?.locked) {
        if (session?.locked == true) {
            ctx.startActivity(Intent(ctx, LockActivity::class.java))
        }
    }

    if (!settings.onboarded) {
        OnboardingScreen(onDone = { Store.saveSettings(settings.copy(onboarded = true)) })
        return
    }

    val tabs = listOf(
        Tab("الرئيسية", Icons.Rounded.Home),
        Tab("الجدولة", Icons.Rounded.Schedule),
        Tab("إحصائيات", Icons.Rounded.BarChart),
        Tab("الإعدادات", Icons.Rounded.Settings)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen()
                1 -> SchedulesScreen()
                2 -> StatsScreen()
                else -> SettingsScreen()
            }
        }
    }
}
