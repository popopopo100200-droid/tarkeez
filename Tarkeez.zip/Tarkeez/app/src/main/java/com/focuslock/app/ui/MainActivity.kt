package com.focuslock.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings as SettingsIcon
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.focuslock.app.core.L
import com.focuslock.app.core.Perms
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.Store

/** التبويب الحالي؛ يبقى عند تغيير اللغة أو الثيم. */
object Nav {
    var tab by mutableIntStateOf(0)
}

class MainActivity : ComponentActivity() {
    companion object {
        /** يُرسَل من الودجت وبلاطة الإعدادات السريعة لبدء آخر جلسة. */
        const val ACTION_QUICK = "com.focuslock.app.QUICK"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestHighRefreshRate()
        handleQuick(intent)
        setContent { TarkeezTheme { AppRoot() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleQuick(intent)
    }

    override fun onResume() {
        super.onResume()
        requestHighRefreshRate()
    }

    private fun handleQuick(i: Intent?) {
        if (i == null || i.action != ACTION_QUICK) return
        i.action = null
        Store.init(this)
        if (!Store.settingsFlow.value.onboarded || Store.session != null) return
        val last = Store.getLast() ?: return
        val lock = last.locked && Perms.accessibilityEnabled(this)
        val minutes = last.pomo?.focusMin ?: last.minutes
        SessionManager.start(this, last.tasks, minutes, lock, last.title, "", last.pomo)
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    val settings by Store.settingsFlow.collectAsState()
    val session by Store.sessionFlow.collectAsState()
    val summary by Store.summaryFlow.collectAsState()
    val tick = rememberTick()

    // أثناء قفل فعّال لا نسمح بالوصول لإعدادات التطبيق: نحوّل لشاشة القفل.
    LaunchedEffect(session?.id, session?.lockActive) {
        if (session?.lockActive == true) {
            ctx.startActivity(Intent(ctx, LockActivity::class.java))
        }
    }

    if (!settings.onboarded) {
        OnboardingScreen(onDone = { Store.saveSettings(settings.copy(onboarded = true)) })
        return
    }

    val sm = summary
    if (sm != null) {
        SummaryScreen(sm, onClose = { Store.summaryFlow.value = null })
        return
    }

    val tabs = listOf(
        Tab(L.tr("الرئيسية", "Home"), Icons.Rounded.Home),
        Tab(L.tr("الجدولة", "Schedule"), Icons.Rounded.Schedule),
        Tab(L.tr("إحصائيات", "Stats"), Icons.Rounded.BarChart),
        Tab(L.tr("الإعدادات", "Settings"), Icons.Rounded.SettingsIcon)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = Nav.tab == i,
                        onClick = {
                            if (Nav.tab != i) tick()
                            Nav.tab = i
                        },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            Crossfade(targetState = Nav.tab, animationSpec = tween(160), label = "tabs") { tab ->
                when (tab) {
                    0 -> HomeScreen()
                    1 -> SchedulesScreen()
                    2 -> StatsScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}
