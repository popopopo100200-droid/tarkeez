package com.focuslock.app.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.view.inputmethod.InputMethodManager
import com.focuslock.app.data.AppSettings
import com.focuslock.app.data.LockMode

/** يقرر هل يُحجب تطبيق معيّن أثناء جلسة مقفلة. */
object Guard {
    /** لا تُحجب أبداً: واجهة النظام والمكالمات والطوارئ. */
    private val ALWAYS_ALLOWED = setOf(
        "com.android.systemui", "android",
        "com.android.incallui", "com.samsung.android.incallui", "com.google.android.dialer",
        "com.android.server.telecom", "com.android.phone", "com.android.emergency"
    )

    /** تُحجب دائماً أثناء الجلسة (إن فُعّلت حماية الإعدادات): الإعدادات ومثبّت الحزم. */
    private val PROTECTED = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    private var cacheAt = 0L
    private var imePkgs: Set<String> = emptySet()
    private var homePkg: String = ""

    private fun refreshCache(ctx: Context) {
        val now = System.currentTimeMillis()
        if (now - cacheAt < 30_000L) return
        cacheAt = now
        try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imePkgs = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) { /* تجاهل */ }
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkg = ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: ""
        } catch (e: Exception) { /* تجاهل */ }
    }

    fun shouldBlock(ctx: Context, pkg: String, st: AppSettings): Boolean {
        if (pkg == ctx.packageName || pkg in ALWAYS_ALLOWED) return false
        refreshCache(ctx)
        if (pkg == homePkg || pkg in imePkgs) return false
        if (st.protectSettings && pkg in PROTECTED) return true
        return when (st.lockMode) {
            LockMode.ALL_EXCEPT_ALLOWED -> pkg !in st.allowedApps
            LockMode.ONLY_SELECTED -> pkg in st.blockedApps
        }
    }
}
