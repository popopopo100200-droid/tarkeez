package com.focuslock.app.ui

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.focuslock.app.core.Perms
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.Session
import com.focuslock.app.data.TaskItem

// ---------------- تنسيق ----------------

fun fmtClock(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

fun fmtMin(m: Int): String = when {
    m < 60 -> "$m دقيقة"
    m % 60 == 0 -> "${m / 60} ساعة"
    else -> "${m / 60} س و ${m % 60} د"
}

// ---------------- عناصر عامة ----------------

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    if (bmp != null) Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size))
}

@Composable
fun TaskChecklist(tasks: List<TaskItem>, onToggle: ((Int) -> Unit)?) {
    Column {
        tasks.forEachIndexed { i, t ->
            val onChange: ((Boolean) -> Unit)? =
                if (onToggle != null) ({ _: Boolean -> onToggle(i) }) else null
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = t.done,
                    onCheckedChange = onChange,
                    enabled = onToggle != null
                )
                Text(
                    t.text,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null,
                    color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DurationPicker(minutes: Int, onChange: (Int) -> Unit) {
    var showInput by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            FilledTonalIconButton(
                onClick = { onChange(if (minutes <= 5) minutes else (minutes - 5).coerceAtLeast(5)) }
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "أنقص")
            }
            Text(
                fmtMin(minutes),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable {
                        typed = minutes.toString()
                        showInput = true
                    }
                    .padding(horizontal = 24.dp)
            )
            FilledTonalIconButton(onClick = { onChange((minutes + 5).coerceAtMost(720)) }) {
                Icon(Icons.Rounded.Add, contentDescription = "زِد")
            }
        }
        Text(
            "اضغط على الرقم لإدخال مدة مخصصة",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
        )
        if (showInput) {
            AlertDialog(
                onDismissRequest = { showInput = false },
                title = { Text("المدة بالدقائق") },
                text = {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { v -> typed = v.filter { it.isDigit() }.take(3) },
                        singleLine = true,
                        label = { Text("من 1 إلى 720") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            typed.toIntOrNull()?.let { onChange(it.coerceIn(1, 720)) }
                            showInput = false
                        },
                        enabled = typed.isNotEmpty()
                    ) { Text("تأكيد") }
                },
                dismissButton = { TextButton(onClick = { showInput = false }) { Text("إلغاء") } }
            )
        }
        Spacer(Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(5, 10, 15, 25, 45, 60, 90, 120).forEach { m ->
                FilterChip(selected = minutes == m, onClick = { onChange(m) }, label = { Text(fmtMin(m)) })
            }
        }
    }
}

/** يزيد قيمته كلما عاد التطبيق للواجهة؛ نستخدمه لإعادة فحص الأذونات. */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) tick++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

// ---------------- سؤال نهاية الجلسة ----------------

/** "هل أكملت مهامك؟" نعم → فتح الهاتف. لا → إبقاؤه مغلقاً لمدة تحددها، أو "ما أنجزته يكفي". */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AskFlow(s: Session, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(15) }
    var lockExt by remember { mutableStateOf(s.locked) }
    val canExtend = SessionManager.canExtend(s)
    val a11yOk = remember { Perms.accessibilityEnabled(ctx) }
    val cap = com.focuslock.app.data.Store.settingsFlow.value.maxExtensions

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (step == 0) {
            Text("انتهى الوقت", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("هل أكملت مهامك؟", style = MaterialTheme.typography.titleMedium)
            TaskChecklist(s.tasks, null)
            Button(
                onClick = { SessionManager.answerYes(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("نعم، أنجزت مهامي")
            }
            OutlinedButton(
                onClick = { step = 1 },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("لا، لم أُكمل بعد") }
        } else {
            Text("حسناً، ماذا تريد الآن؟", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (canExtend) {
                Text(if (s.locked) "أبقِ الهاتف مغلقاً لمدة تحددها:" else "مدّد الوقت لمدة تحددها:")
                DurationPicker(minutes) { minutes = it }
                if (!s.locked && a11yOk) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = lockExt, onCheckedChange = { lockExt = it })
                        Spacer(Modifier.width(8.dp))
                        Text("قفل الهاتف أثناء التمديد")
                    }
                }
                Button(
                    onClick = { SessionManager.extend(ctx, minutes, if (s.locked) null else lockExt) },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(if (s.locked) "أبقِ الهاتف مغلقاً" else "مدّد الوقت") }
                if (cap > 0) {
                    Text(
                        "التمديدات المتبقية: ${(cap - s.extensions).coerceAtLeast(0)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    "وصلت إلى الحد الأقصى للتمديد ($cap مرات).",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = { SessionManager.answerEnough(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("ما أنجزته يكفي، افتح الهاتف") }
            TextButton(onClick = { step = 0 }) { Text("رجوع") }
        }
    }
}

// ---------------- الأذونات ----------------

@Composable
private fun PermRow(title: String, desc: String, ok: Boolean, actionLabel: String?, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (ok) {
                    Icon(
                        Icons.Rounded.CheckCircle, contentDescription = "مفعّل",
                        tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (actionLabel != null) {
            Spacer(Modifier.width(8.dp))
            if (ok) OutlinedButton(onClick = onAction) { Text(actionLabel) }
            else Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

private fun openAppDetails(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

@Composable
fun PermissionsPanel() {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { Perms.accessibilityEnabled(ctx) }
    val notif = remember(tick) { Perms.notificationsGranted(ctx) }
    val overlay = remember(tick) { Perms.overlayGranted(ctx) }
    val admin = remember(tick) { Perms.adminActive(ctx) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PermRow(
            "خدمة القفل (إمكانية الوصول)",
            "مطلوبة للقفل. تكتشف التطبيق المفتوح لحجبه أثناء الجلسة فقط، ولا تقرأ أي محتوى.",
            a11y, "تفعيل"
        ) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        if (!a11y) {
            Text(
                "إن كان الخيار رمادياً (أندرويد 13 فأعلى): افتح معلومات التطبيق ← القائمة ⋮ ← «السماح بالإعدادات المقيّدة»، ثم ارجع وفعّل الخدمة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { openAppDetails(ctx) }) { Text("فتح معلومات التطبيق") }
        }
        PermRow("الإشعارات", "لتنبيهك قبل انتهاء الوقت وعند السؤال عن مهامك.", notif, "السماح") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else ctx.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            )
        }
        PermRow("العرض فوق التطبيقات", "يساعد على إظهار شاشة القفل فوراً (موصى به).", overlay, "السماح") {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }
        PermRow(
            "الحماية من الحذف",
            "اختياري. يمنع حذف التطبيق ما دامت الحماية مفعّلة.",
            admin, if (admin) "إلغاء" else "تفعيل"
        ) {
            if (admin) {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                dpm.removeActiveAdmin(Perms.adminComponent(ctx))
            } else {
                ctx.startActivity(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, Perms.adminComponent(ctx))
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "لمنع حذف تطبيق تركيز أثناء جلسات التركيز.")
                )
            }
        }
    }
}
