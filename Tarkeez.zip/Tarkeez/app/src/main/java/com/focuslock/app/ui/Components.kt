package com.focuslock.app.ui

import android.Manifest
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.focuslock.app.core.Dnd
import com.focuslock.app.core.L
import com.focuslock.app.core.Perms
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.Pomo
import com.focuslock.app.data.Session
import com.focuslock.app.data.Store
import com.focuslock.app.data.TaskItem
import kotlinx.coroutines.delay

// ---------------- تنسيق ----------------

fun fmtClock(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

fun fmtMin(m: Int): String = when {
    m < 60 -> L.tr("$m دقيقة", "$m min")
    m % 60 == 0 -> L.tr("${m / 60} ساعة", "${m / 60} h")
    else -> L.tr("${m / 60} س و ${m % 60} د", "${m / 60}h ${m % 60}m")
}

/** ساعة تُحدَّث كل [periodMs]؛ تُقرأ في أصغر مكوّن ممكن حتى لا تُعاد رسم الشاشة كلها كل ثانية. */
@Composable
fun rememberNow(periodMs: Long = 1000L): State<Long> =
    produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(periodMs)
        }
    }

/** اهتزاز خفيف عند اللمس. */
@Composable
fun rememberTick(): () -> Unit {
    val h = LocalHapticFeedback.current
    return remember(h) { { h.performHapticFeedback(HapticFeedbackType.TextHandleMove) } }
}

// ---------------- عناصر عامة ----------------

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
}

@Composable
fun ScreenTitle(title: String, sub: String? = null) {
    Column {
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        if (sub != null) Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    if (bmp != null) Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size))
}

/** حلقة تقدّم؛ [progress] دالة تُقرأ أثناء الرسم فقط فلا تُعاد التركيبة كل إطار. */
@Composable
fun ProgressRing(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 12.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    track: Color = MaterialTheme.colorScheme.surfaceVariant,
    content: @Composable BoxScope.() -> Unit = {}
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val topLeft = Offset(sw / 2f, sw / 2f)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(
                color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = topLeft, size = sz, style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            val p = progress().coerceIn(0f, 1f)
            if (p > 0f) {
                drawArc(
                    color = color, startAngle = -90f, sweepAngle = 360f * p, useCenter = false,
                    topLeft = topLeft, size = sz, style = Stroke(width = sw, cap = StrokeCap.Round)
                )
            }
        }
        content()
    }
}

@Composable
fun TaskChecklist(tasks: List<TaskItem>, onToggle: ((Int) -> Unit)?) {
    val tick = rememberTick()
    Column {
        tasks.forEachIndexed { i, t ->
            val onChange: ((Boolean) -> Unit)? =
                if (onToggle != null) ({ _: Boolean -> tick(); onToggle(i) }) else null
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = t.done,
                    onCheckedChange = onChange,
                    enabled = onToggle != null
                )
                Text(
                    t.text,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null,
                    color = if (t.done) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/** عدّاد بزرّي + و − مع قيمة نصية. */
@Composable
fun Stepper(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    val tick = rememberTick()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalIconButton(onClick = { tick(); onMinus() }) {
            Icon(Icons.Rounded.Remove, contentDescription = L.tr("أنقص", "Decrease"))
        }
        Spacer(Modifier.width(6.dp))
        FilledTonalIconButton(onClick = { tick(); onPlus() }) {
            Icon(Icons.Rounded.Add, contentDescription = L.tr("زِد", "Increase"))
        }
    }
}

/** اختيار المدة: شريط تمرير (خطوة 5 دقائق) + أزرار + إدخال رقم + اختصارات. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DurationPicker(minutes: Int, onChange: (Int) -> Unit) {
    val tick = rememberTick()
    var showInput by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            FilledTonalIconButton(
                onClick = {
                    tick()
                    onChange((if (minutes > 5) minutes - 5 else minutes).coerceAtLeast(1))
                }
            ) { Icon(Icons.Rounded.Remove, contentDescription = L.tr("أنقص", "Decrease")) }
            Text(
                fmtMin(minutes),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable {
                        typed = minutes.toString()
                        showInput = true
                    }
                    .padding(horizontal = 24.dp, vertical = 4.dp)
            )
            FilledTonalIconButton(onClick = { tick(); onChange((minutes + 5).coerceAtMost(720)) }) {
                Icon(Icons.Rounded.Add, contentDescription = L.tr("زِد", "Increase"))
            }
        }
        Slider(
            value = minutes.coerceIn(5, 240).toFloat(),
            onValueChange = { v ->
                val m = (Math.round(v / 5f) * 5).coerceIn(5, 240)
                if (m != minutes) {
                    tick()
                    onChange(m)
                }
            },
            valueRange = 5f..240f
        )
        Text(
            L.tr("اسحب الشريط، أو اضغط على الرقم لإدخال مدة مخصصة", "Drag the slider, or tap the number to type a custom time"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth()
        )
        if (showInput) {
            AlertDialog(
                onDismissRequest = { showInput = false },
                title = { Text(L.tr("المدة بالدقائق", "Duration in minutes")) },
                text = {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { v -> typed = v.filter { it.isDigit() }.take(3) },
                        singleLine = true,
                        label = { Text(L.tr("من 1 إلى 720", "1 to 720")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            typed.toIntOrNull()?.let { onChange(it.coerceIn(1, 720)) }
                            showInput = false
                        },
                        enabled = typed.isNotEmpty()
                    ) { Text(L.tr("تأكيد", "OK")) }
                },
                dismissButton = {
                    TextButton(onClick = { showInput = false }) { Text(L.tr("إلغاء", "Cancel")) }
                }
            )
        }
        Spacer(Modifier.height(4.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(15, 25, 45, 60, 90, 120).forEach { m ->
                FilterChip(selected = minutes == m, onClick = { tick(); onChange(m) }, label = { Text(fmtMin(m)) })
            }
        }
    }
}

/** تخصيص بومودورو: مدة التركيز والراحة القصيرة والطويلة وعدد الدورات. */
@Composable
fun PomoEditor(p: Pomo, onChange: (Pomo) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Stepper(
            L.tr("مدة التركيز", "Focus length"), fmtMin(p.focusMin),
            { onChange(p.copy(focusMin = (p.focusMin - 5).coerceAtLeast(5))) },
            { onChange(p.copy(focusMin = (p.focusMin + 5).coerceAtMost(120))) }
        )
        Stepper(
            L.tr("الراحة القصيرة", "Short break"), fmtMin(p.breakMin),
            { onChange(p.copy(breakMin = (p.breakMin - 1).coerceAtLeast(1))) },
            { onChange(p.copy(breakMin = (p.breakMin + 1).coerceAtMost(30))) }
        )
        Stepper(
            L.tr("الراحة الطويلة (كل 4 دورات)", "Long break (every 4 rounds)"), fmtMin(p.longBreakMin),
            { onChange(p.copy(longBreakMin = (p.longBreakMin - 5).coerceAtLeast(5))) },
            { onChange(p.copy(longBreakMin = (p.longBreakMin + 5).coerceAtMost(60))) }
        )
        Stepper(
            L.tr("عدد الدورات", "Number of rounds"), "${p.cycles}",
            { onChange(p.copy(cycles = (p.cycles - 1).coerceAtLeast(1))) },
            { onChange(p.copy(cycles = (p.cycles + 1).coerceAtMost(12))) }
        )
        Text(
            L.tr(
                "إجمالي وقت التركيز: ${fmtMin(p.focusMin * p.cycles)}",
                "Total focus time: ${fmtMin(p.focusMin * p.cycles)}"
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** يزيد قيمته كلما عاد التطبيق للواجهة؛ نستخدمه لإعادة فحص الأذونات. */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) tick++
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

// ---------------- سؤال نهاية الجلسة ----------------

/** "هل أكملت مهامك؟" نعم → فتح الهاتف. لا → إبقاؤه مغلقاً لمدة تحددها، أو "ما أنجزته يكفي". */
@Composable
fun AskFlow(s: Session, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val tick = rememberTick()
    var step by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(15) }
    var lockExt by remember { mutableStateOf(s.locked) }
    val canExtend = SessionManager.canExtend(s)
    val a11yOk = remember { Perms.accessibilityEnabled(ctx) }
    val cap = Store.settingsFlow.value.maxExtensions

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (step == 0) {
            Text(L.tr("انتهى الوقت", "Time is up"), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(L.tr("هل أكملت مهامك؟", "Did you finish your tasks?"), style = MaterialTheme.typography.titleMedium)
            TaskChecklist(s.tasks, null)
            Button(
                onClick = { tick(); SessionManager.answerYes(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(L.tr("نعم، أنجزت مهامي", "Yes, I finished"))
            }
            OutlinedButton(
                onClick = { tick(); step = 1 },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(L.tr("لا، لم أُكمل بعد", "No, not yet")) }
        } else {
            Text(L.tr("حسناً، ماذا تريد الآن؟", "OK, what now?"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (canExtend) {
                Text(
                    if (s.locked) L.tr("أبقِ الهاتف مغلقاً لمدة تحددها:", "Keep the phone locked for:")
                    else L.tr("مدّد الوقت لمدة تحددها:", "Extend the time by:")
                )
                DurationPicker(minutes) { minutes = it }
                if (!s.locked && a11yOk) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = lockExt, onCheckedChange = { lockExt = it })
                        Spacer(Modifier.width(8.dp))
                        Text(L.tr("قفل الهاتف أثناء التمديد", "Lock the phone during the extension"))
                    }
                }
                Button(
                    onClick = { tick(); SessionManager.extend(ctx, minutes, if (s.locked) null else lockExt) },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(
                        if (s.locked) L.tr("أبقِ الهاتف مغلقاً", "Keep it locked")
                        else L.tr("مدّد الوقت", "Extend time")
                    )
                }
                if (cap > 0) {
                    val left = (cap - s.extensions).coerceAtLeast(0)
                    Text(
                        L.tr("التمديدات المتبقية: $left", "Extensions left: $left"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    L.tr("وصلت إلى الحد الأقصى للتمديد ($cap مرات).", "You reached the extension limit ($cap)."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = { tick(); SessionManager.answerEnough(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(L.tr("ما أنجزته يكفي، افتح الهاتف", "What I did is enough, unlock")) }
            TextButton(onClick = { step = 0 }) { Text(L.tr("رجوع", "Back")) }
        }
    }
}

// ---------------- الأذونات وجاهزية التطبيق ----------------

@Composable
private fun PermRow(title: String, desc: String, ok: Boolean, actionLabel: String?, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (ok) {
                    Icon(
                        Icons.Rounded.CheckCircle, contentDescription = L.tr("مفعّل", "Enabled"),
                        tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (actionLabel != null) {
            Spacer(Modifier.width(8.dp))
            if (ok) OutlinedButton(onClick = onAction) { Text(actionLabel) }
            else Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

private fun openAppDetails(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )
}

/** عدد الأذونات الضرورية الجاهزة من إجمالي المطلوب (الحماية من الحذف اختيارية فلا تُحسب). */
fun readiness(ctx: Context): Pair<Int, Int> {
    val dndOn = Store.settingsFlow.value.dnd
    val checks = mutableListOf(
        Perms.accessibilityEnabled(ctx),
        Perms.notificationsGranted(ctx),
        Perms.overlayGranted(ctx),
        Perms.exactAlarms(ctx),
        Perms.batteryIgnored(ctx)
    )
    if (dndOn) checks += Dnd.granted(ctx)
    return checks.count { it } to checks.size
}

@Composable
fun PermissionsPanel() {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val a11y = remember(tick) { Perms.accessibilityEnabled(ctx) }
    val notif = remember(tick) { Perms.notificationsGranted(ctx) }
    val overlay = remember(tick) { Perms.overlayGranted(ctx) }
    val admin = remember(tick) { Perms.adminActive(ctx) }
    val exact = remember(tick) { Perms.exactAlarms(ctx) }
    val battery = remember(tick) { Perms.batteryIgnored(ctx) }
    val dndOn = Store.settingsFlow.value.dnd
    val dndOk = remember(tick) { Dnd.granted(ctx) }
    val (ready, total) = remember(tick, dndOn) { readiness(ctx) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val enable = L.tr("تفعيل", "Enable")
    val allow = L.tr("السماح", "Allow")

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            if (ready == total) L.tr("كل شيء جاهز ✓", "Everything is ready ✓")
            else L.tr("الجاهزية: $ready من $total", "Readiness: $ready of $total"),
            style = MaterialTheme.typography.titleSmall,
            color = if (ready == total) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold
        )
        PermRow(
            L.tr("خدمة القفل (إمكانية الوصول)", "Lock service (Accessibility)"),
            L.tr(
                "مطلوبة للقفل. تكتشف التطبيق المفتوح لحجبه أثناء الجلسة فقط، ولا تقرأ أي محتوى.",
                "Required for locking. Detects the open app to block it during a session only; it reads no content."
            ),
            a11y, enable
        ) { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        if (!a11y) {
            Text(
                L.tr(
                    "إن كان الخيار رمادياً (أندرويد 13 فأعلى): افتح معلومات التطبيق ← القائمة ⋮ ← «السماح بالإعدادات المقيّدة»، ثم ارجع وفعّل الخدمة.",
                    "If the option is greyed out (Android 13+): open App info → ⋮ menu → “Allow restricted settings”, then come back and enable the service."
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { openAppDetails(ctx) }) { Text(L.tr("فتح معلومات التطبيق", "Open App info")) }
        }
        PermRow(
            L.tr("الإشعارات", "Notifications"),
            L.tr("لتنبيهك قبل انتهاء الوقت وعند السؤال عن مهامك.", "To warn you before time is up and to ask about your tasks."),
            notif, allow
        ) {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else ctx.startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            )
        }
        PermRow(
            L.tr("العرض فوق التطبيقات", "Display over other apps"),
            L.tr("يساعد على إظهار شاشة القفل فوراً (موصى به).", "Helps show the lock screen instantly (recommended)."),
            overlay, allow
        ) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }
        PermRow(
            L.tr("المنبّهات الدقيقة", "Exact alarms"),
            L.tr("ليبدأ السؤال في لحظة انتهاء الوقت بالضبط.", "So the end-of-time prompt fires at the exact moment."),
            exact, allow
        ) {
            if (Build.VERSION.SDK_INT >= 31) {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                )
            }
        }
        PermRow(
            L.tr("استثناء من توفير البطارية", "Battery optimization exemption"),
            L.tr(
                "حتى لا يوقف النظام التطبيق في الخلفية أثناء الجلسة.",
                "So the system does not stop the app in the background during a session."
            ),
            battery, allow
        ) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                )
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        if (dndOn) {
            PermRow(
                L.tr("الوصول لسياسة الإشعارات", "Notification policy access"),
                L.tr("مطلوب لتفعيل «عدم الإزعاج» أثناء الجلسة ثم إعادته كما كان.", "Needed to turn on Do Not Disturb during a session and restore it afterwards."),
                dndOk, allow
            ) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        }
        PermRow(
            L.tr("الحماية من الحذف", "Uninstall protection"),
            L.tr("اختياري. يمنع حذف التطبيق ما دامت الحماية مفعّلة.", "Optional. Prevents uninstalling the app while protection is on."),
            admin, if (admin) L.tr("إلغاء", "Disable") else enable
        ) {
            if (admin) {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                dpm.removeActiveAdmin(Perms.adminComponent(ctx))
            } else {
                ctx.startActivity(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, Perms.adminComponent(ctx))
                        .putExtra(
                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            L.tr("لمنع حذف تطبيق Tarkeez أثناء جلسات التركيز.", "To prevent uninstalling Tarkeez during focus sessions.")
                        )
                )
            }
        }
    }
}
