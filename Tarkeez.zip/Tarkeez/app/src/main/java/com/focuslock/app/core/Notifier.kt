package com.focuslock.app.core

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focuslock.app.R
import com.focuslock.app.data.Segment
import com.focuslock.app.data.Session
import com.focuslock.app.ui.LockActivity
import com.focuslock.app.ui.MainActivity

@SuppressLint("MissingPermission")
object Notifier {
    private const val CH_SESSION = "session"
    private const val CH_ALERT = "alert"
    private const val ID_ONGOING = 1
    private const val ID_ALERT = 2
    private const val ID_TAMPER = 3

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CH_SESSION, L.tr("الجلسة الجارية", "Current session"),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        // الصوت والاهتزاز تتولاهما Alerts (ويمكن إيقافهما من الإعدادات)
        val alert = NotificationChannel(
            CH_ALERT, L.tr("تنبيهات التركيز", "Focus alerts"), NotificationManager.IMPORTANCE_HIGH
        )
        alert.setSound(null, null)
        alert.enableVibration(false)
        nm.createNotificationChannel(alert)
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) { /* لا إذن إشعارات */ }
    }

    private fun target(ctx: Context, s: Session?): PendingIntent {
        val cls = if (s?.lockActive == true) LockActivity::class.java else MainActivity::class.java
        return PendingIntent.getActivity(
            ctx, 11,
            Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showOngoing(ctx: Context, s: Session) {
        val onBreak = s.segment == Segment.BREAK
        val text = when {
            onBreak -> L.tr("استرح قليلاً — سيعود التركيز تلقائياً", "Take a break — focus resumes automatically")
            s.lockActive -> L.tr("الهاتف مقفل حتى انتهاء الوقت", "Phone is locked until time is up")
            else -> s.tasks.firstOrNull()?.text ?: ""
        }
        val title = when {
            onBreak -> L.tr("استراحة", "Break")
            s.title.isNotBlank() -> s.title
            else -> L.tr("جلسة تركيز جارية", "Focus session in progress")
        }
        val n = NotificationCompat.Builder(ctx, CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(title)
            .setContentText(text)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(s.endMs)
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ONGOING, n)
    }

    fun showWarn(ctx: Context, s: Session) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("تبقّت دقيقتان", "2 minutes left"))
            .setContentText(L.tr("استعد لإنهاء مهامك", "Get ready to wrap up your tasks"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    /** بداية استراحة بومودورو. */
    fun showBreakStart(ctx: Context, s: Session) {
        val min = ((s.endMs - s.segStartMs) / 60_000L).toInt()
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("وقت الاستراحة", "Break time"))
            .setContentText(L.tr("استرح $min دقيقة — تم فتح الهاتف مؤقتاً", "Rest for $min min — phone is unlocked for now"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    /** عودة التركيز بعد الاستراحة. */
    fun showFocusResume(ctx: Context, s: Session) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("عُد للتركيز", "Back to focus"))
            .setContentText(L.tr("الدورة ${s.cycle + 1} من ${s.pomo?.cycles ?: 1}", "Round ${s.cycle + 1} of ${s.pomo?.cycles ?: 1}"))
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showAsk(ctx: Context, s: Session) {
        val pi = target(ctx, s)
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("انتهى الوقت", "Time is up"))
            .setContentText(L.tr("هل أكملت مهامك؟ اضغط للإجابة", "Did you finish your tasks? Tap to answer"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(false)
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showTamper(ctx: Context) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle(L.tr("تم إيقاف خدمة القفل", "Lock service was turned off"))
            .setContentText(
                L.tr(
                    "أعد تفعيلها من إعدادات إمكانية الوصول لمتابعة جلستك",
                    "Re-enable it in Accessibility settings to continue your session"
                )
            )
            .setAutoCancel(true)
            .setContentIntent(target(ctx, null))
            .build()
        post(ctx, ID_TAMPER, n)
    }

    fun cancelSession(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_ONGOING)
        nm.cancel(ID_ALERT)
    }
}
