package com.focuslock.app.core

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focuslock.app.R
import com.focuslock.app.data.Session
import com.focuslock.app.ui.LockActivity
import com.focuslock.app.ui.MainActivity

@SuppressLint("MissingPermission")
object Notifier {
    private const val CH_SESSION = "session"
    private const val CH_ALERT = "alert"
    private const val ID_ONGOING = 1
    private const val ID_ALERT = 2
    private const val ID_TAMPER = 3

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_SESSION, "الجلسة الجارية", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "تنبيهات التركيز", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) { /* لا إذن إشعارات */ }
    }

    private fun target(ctx: Context, s: Session?): PendingIntent {
        val cls = if (s?.locked == true) LockActivity::class.java else MainActivity::class.java
        return PendingIntent.getActivity(
            ctx, 11,
            Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showOngoing(ctx: Context, s: Session) {
        val text = if (s.locked) "الهاتف مقفل حتى انتهاء الوقت" else (s.tasks.firstOrNull()?.text ?: "")
        val n = NotificationCompat.Builder(ctx, CH_SESSION)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("جلسة تركيز جارية")
            .setContentText(text)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(s.endMs)
            .setShowWhen(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ONGOING, n)
    }

    fun showWarn(ctx: Context, s: Session) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("تبقّت دقيقتان")
            .setContentText("استعد لإنهاء مهامك")
            .setAutoCancel(true)
            .setContentIntent(target(ctx, s))
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showAsk(ctx: Context, s: Session) {
        val pi = target(ctx, s)
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("انتهى الوقت")
            .setContentText("هل أكملت مهامك؟ اضغط للإجابة")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)
            .setContentIntent(pi)
            .setAutoCancel(false)
            .build()
        post(ctx, ID_ALERT, n)
    }

    fun showTamper(ctx: Context) {
        val n = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("تم إيقاف خدمة القفل")
            .setContentText("أعد تفعيلها من إعدادات إمكانية الوصول لمتابعة جلستك")
            .setAutoCancel(true)
            .setContentIntent(target(ctx, null))
            .build()
        post(ctx, ID_TAMPER, n)
    }

    fun cancelSession(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_ONGOING)
        nm.cancel(ID_ALERT)
    }
}
