package com.focuslock.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.focuslock.app.core.Apps
import com.focuslock.app.core.L
import com.focuslock.app.data.DayStat
import com.focuslock.app.data.Result
import com.focuslock.app.data.Stats
import com.focuslock.app.data.Store
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen() {
    val ctx = LocalContext.current
    val history by Store.historyFlow.collectAsState()
    val attempts by Store.attemptsFlow.collectAsState()
    val settings by Store.settingsFlow.collectAsState()

    // نحسب مرة واحدة لكل تغيّر في السجل بدل كل إعادة رسم (تمرير أسلس)
    val week = remember(history) { Stats.lastWeek(history) }
    val rate = remember(history) { Stats.onTimeRate(history) }
    val heat = remember(history) { Stats.heatmap(history, 35) }
    val thisWeek = remember(history) { Stats.weekMinutes(history) }
    val prevWeek = remember(history) { Stats.previousWeekMinutes(history) }
    val today = remember(history) { Stats.todayMinutes(history) }
    val streak = remember(history) { Stats.streak(history) }
    val tasksDone = remember(history) { Stats.totalTasksDone(history) }
    val topApps = remember(attempts) {
        attempts.entries.sortedByDescending { it.value }.take(5).map { Triple(it.key, Apps.label(ctx, it.key), it.value) }
    }
    val fmt = remember { SimpleDateFormat("d/M  HH:mm", Locale.US) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle(L.tr("إحصائياتك", "Your stats"))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), L.tr("اليوم", "Today"), fmtMin(today))
            StatTile(Modifier.weight(1f), L.tr("هذا الأسبوع", "This week"), fmtMin(thisWeek))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), L.tr("أيام متتالية", "Day streak"), "$streak")
            StatTile(Modifier.weight(1f), L.tr("مهام منجزة", "Tasks done"), "$tasksDone")
        }

        SectionCard {
            SectionTitle(L.tr("آخر 7 أيام", "Last 7 days"))
            WeekBars(week)
            Spacer(Modifier.height(10.dp))
            Text(weekCompare(thisWeek, prevWeek), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard {
            SectionTitle(L.tr("خريطة آخر 5 أسابيع", "Last 5 weeks heatmap"))
            Heatmap(heat, settings.dailyGoalMin)
            Spacer(Modifier.height(6.dp))
            Text(
                L.tr("كلما اشتد اللون زاد تركيزك في ذلك اليوم (الهدف ${fmtMin(settings.dailyGoalMin)}).",
                    "Darker = more focus that day (goal ${fmtMin(settings.dailyGoalMin)})."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard {
            SectionTitle(L.tr("ما الذي شتّتك؟", "What distracted you?"))
            if (topApps.isEmpty()) {
                Text(
                    L.tr("لا محاولات مسجّلة. سنعرض هنا التطبيقات التي حاولت فتحها أثناء القفل.",
                        "No attempts yet. Apps you tried to open during a lock will show here."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                topApps.forEach { (pkg, label, n) ->
                    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(pkg, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(label, modifier = Modifier.weight(1f))
                        Text(L.tr("$n مرة", "$n×"), fontWeight = FontWeight.Bold)
                    }
                }
                TextButton(onClick = { Store.clearAttempts() }) { Text(L.tr("تصفير", "Reset")) }
            }
        }

        SectionCard {
            SectionTitle(L.tr("دقة تقديرك للوقت", "Your time-estimate accuracy"))
            if (rate == null) {
                Text(L.tr("ستظهر بعد إكمال أول جلسة.", "Shown after your first session."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("$rate%", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text(
                    L.tr("من جلساتك انتهت في الوقت الذي قدّرته دون تمديد.", "of your sessions ended within the time you estimated, with no extension."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    when {
                        rate < 60 -> L.tr("تميل لتقدير الوقت بأقل من اللازم. جرّب أن تزيد تقديراتك بنحو 25%.", "You tend to underestimate. Try adding about 25% to your estimates.")
                        rate >= 85 -> L.tr("تقديراتك دقيقة جداً، استمر.", "Your estimates are very accurate. Keep going.")
                        else -> L.tr("تقديراتك جيدة، وتحتاج تعديلاً بسيطاً.", "Your estimates are good and need only a small tweak.")
                    }
                )
            }
        }

        SectionCard {
            SectionTitle(L.tr("آخر الجلسات", "Recent sessions"))
            if (history.isEmpty()) {
                Text(L.tr("لا توجد جلسات بعد.", "No sessions yet."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            history.take(10).forEach { h ->
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    when (h.result) {
                        Result.COMPLETED -> Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(22.dp))
                        Result.PARTIAL -> Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                        Result.ABANDONED -> Icon(Icons.Rounded.Close, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            (if (h.title.isNotBlank()) "${h.title} · " else "") +
                                L.tr(
                                    "${h.tasksDone}/${h.tasksTotal} مهام · ${fmtMin(h.actualMin)} من ${fmtMin(h.plannedMin)}",
                                    "${h.tasksDone}/${h.tasksTotal} tasks · ${fmtMin(h.actualMin)} of ${fmtMin(h.plannedMin)}"
                                ),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            when (h.result) {
                                Result.COMPLETED -> L.tr("مكتملة", "Completed")
                                Result.PARTIAL -> L.tr("جزئية", "Partial")
                                Result.ABANDONED -> L.tr("ملغاة", "Abandoned")
                            } + (if (h.locked) L.tr(" · مقفلة", " · locked") else "") +
                                (if (h.extensions > 0) L.tr(" · تمديد ×${h.extensions}", " · extended ×${h.extensions}") else "") +
                                (if (h.attempts > 0) L.tr(" · ${h.attempts} محاولة", " · ${h.attempts} attempts") else ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        fmt.format(Date(h.endMs)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (history.isNotEmpty()) {
            TextButton(onClick = { Store.clearHistory() }) { Text(L.tr("مسح السجل", "Clear history")) }
        }
        Spacer(Modifier.height(12.dp))
    }
}

private fun weekCompare(cur: Int, prev: Int): String {
    if (prev == 0 && cur == 0) return L.tr("لا بيانات كافية للمقارنة بعد.", "Not enough data to compare yet.")
    if (prev == 0) return L.tr("أسبوع جديد! لا بيانات للأسبوع السابق للمقارنة.", "New week! No previous-week data to compare.")
    val pct = (cur - prev) * 100 / prev
    return when {
        pct > 0 -> L.tr("أفضل من الأسبوع الماضي بنسبة $pct% (${fmtMin(cur)} مقابل ${fmtMin(prev)}).",
            "$pct% better than last week (${fmtMin(cur)} vs ${fmtMin(prev)}).")
        pct < 0 -> L.tr("أقل من الأسبوع الماضي بنسبة ${-pct}% (${fmtMin(cur)} مقابل ${fmtMin(prev)}).",
            "${-pct}% lower than last week (${fmtMin(cur)} vs ${fmtMin(prev)}).")
        else -> L.tr("مثل الأسبوع الماضي تماماً.", "Same as last week.")
    }
}

@Composable
private fun StatTile(modifier: Modifier, label: String, value: String) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Heatmap(values: List<Int>, goal: Int) {
    val base = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.surfaceVariant
    val g = goal.coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        values.chunked(7).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                row.forEach { v ->
                    val a = if (v <= 0) 0f else (0.25f + 0.75f * (v.toFloat() / g).coerceAtMost(1f))
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .background(if (v <= 0) empty else base.copy(alpha = a), RoundedCornerShape(6.dp))
                    )
                }
                repeat(7 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun WeekBars(days: List<DayStat>) {
    val max = (days.maxOfOrNull { it.minutes } ?: 0).coerceAtLeast(30)
    Row(
        Modifier.fillMaxWidth().height(150.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        days.forEach { d ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    val h = (d.minutes.toFloat() / max * 100f).coerceAtLeast(4f)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(h.dp)
                            .background(
                                if (d.isToday) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                                RoundedCornerShape(6.dp)
                            )
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(d.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
