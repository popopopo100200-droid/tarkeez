package com.focuslock.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.focuslock.app.data.DayStat
import com.focuslock.app.data.Result
import com.focuslock.app.data.Stats
import com.focuslock.app.data.Store
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen() {
    val history by Store.historyFlow.collectAsState()
    val week = Stats.lastWeek(history)
    val rate = Stats.onTimeRate(history)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("إحصائياتك", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), "اليوم", fmtMin(Stats.todayMinutes(history)))
            StatTile(Modifier.weight(1f), "هذا الأسبوع", fmtMin(Stats.weekMinutes(history)))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), "أيام متتالية", "${Stats.streak(history)}")
            StatTile(Modifier.weight(1f), "مهام منجزة", "${Stats.totalTasksDone(history)}")
        }

        SectionCard {
            Text("آخر 7 أيام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            WeekBars(week)
        }

        SectionCard {
            Text("دقة تقديرك للوقت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            if (rate == null) {
                Text("ستظهر بعد إكمال أول جلسة.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("$rate%", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text(
                    "من جلساتك انتهت في الوقت الذي قدّرته دون تمديد.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    when {
                        rate < 60 -> "تميل لتقدير الوقت بأقل من اللازم. جرّب أن تزيد تقديراتك بنحو 25%."
                        rate >= 85 -> "تقديراتك دقيقة جداً، استمر."
                        else -> "تقديراتك جيدة، وتحتاج تعديلاً بسيطاً."
                    }
                )
            }
        }

        SectionCard {
            Text("آخر الجلسات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (history.isEmpty()) {
                Text("لا توجد جلسات بعد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val fmt = SimpleDateFormat("d/M  HH:mm", Locale.US)
            history.take(10).forEach { h ->
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    when (h.result) {
                        Result.COMPLETED -> Icon(
                            Icons.Rounded.CheckCircle, contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(22.dp)
                        )
                        Result.PARTIAL -> Icon(
                            Icons.Rounded.Check, contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp)
                        )
                        Result.ABANDONED -> Icon(
                            Icons.Rounded.Close, contentDescription = null,
                            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            (if (h.title.isNotBlank()) "${h.title} · " else "") +
                                "${h.tasksDone}/${h.tasksTotal} مهام · ${fmtMin(h.actualMin)} من ${fmtMin(h.plannedMin)}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            when (h.result) {
                                Result.COMPLETED -> "مكتملة"
                                Result.PARTIAL -> "جزئية"
                                Result.ABANDONED -> "ملغاة"
                            } + (if (h.locked) " · مقفلة" else "") +
                                (if (h.extensions > 0) " · تمديد ×${h.extensions}" else ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        fmt.format(Date(h.endMs)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (history.isNotEmpty()) {
            TextButton(onClick = { Store.clearHistory() }) { Text("مسح السجل") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StatTile(modifier: Modifier, label: String, value: String) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WeekBars(days: List<DayStat>) {
    val max = (days.maxOfOrNull { it.minutes } ?: 0).coerceAtLeast(30)
    Row(
        Modifier.fillMaxWidth().height(150.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        days.forEach { d ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    val h = (d.minutes.toFloat() / max * 100f).coerceAtLeast(4f)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(h.dp)
                            .background(
                                if (d.isToday) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                                RoundedCornerShape(6.dp)
                            )
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(d.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
