package com.focuslock.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.focuslock.app.core.L
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Pomo
import com.focuslock.app.data.Segment
import com.focuslock.app.data.Session
import com.focuslock.app.data.Stats
import com.focuslock.app.data.Store
import com.focuslock.app.data.Template
import kotlinx.coroutines.delay

/** مسودة الجلسة الجاري تحضيرها؛ تبقى عند التنقل بين التبويبات. */
object Draft {
    var tasks by mutableStateOf(listOf<String>())
    var input by mutableStateOf("")
    var minutes by mutableIntStateOf(45)
    var title by mutableStateOf("")
    var note by mutableStateOf("")
    var pomoOn by mutableStateOf(false)
    var pomo by mutableStateOf<Pomo?>(null)

    fun clear() {
        tasks = emptyList()
        input = ""
        title = ""
        note = ""
    }

    fun apply(t: Template) {
        tasks = t.tasks
        minutes = t.minutes
        title = t.title
        pomoOn = t.pomo != null
        if (t.pomo != null) pomo = t.pomo
    }
}

private fun builtinTemplates(): List<Template> = listOf(
    Template(-1, L.tr("مذاكرة", "Study"), listOf(L.tr("مراجعة الدرس", "Review the lesson")), 45, false),
    Template(-2, L.tr("عمل عميق", "Deep work"), listOf(L.tr("المهمة الأهم اليوم", "Today's top task")), 90, false),
    Template(-3, L.tr("قراءة", "Reading"), listOf(L.tr("قراءة 20 صفحة", "Read 20 pages")), 30, false),
    Template(-4, L.tr("بومودورو", "Pomodoro"), listOf(L.tr("مهمة واحدة بتركيز", "One focused task")), 100, false,
        Pomo(25, 5, 15, 4))
)

/** نص عدّاد تنازلي يحدّث نفسه فقط (لا يعيد تركيب ما حوله). */
@Composable
fun ClockText(endMs: Long, style: TextStyle, color: Color = Color.Unspecified) {
    val now by rememberNow(500L)
    Text(fmtClock(endMs - now), style = style, color = color)
}

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val session by Store.sessionFlow.collectAsState()
    val history by Store.historyFlow.collectAsState()
    val settings by Store.settingsFlow.collectAsState()
    val tick = rememberResumeTick()
    val ready = remember(tick, settings.dnd) { readiness(ctx) }
    val a11yOk = remember(tick) { com.focuslock.app.core.Perms.accessibilityEnabled(ctx) }

    LaunchedEffect(session?.id) {
        while (Store.session != null) {
            SessionManager.checkExpiry(ctx)
            delay(1000)
        }
    }

    val streak = remember(history) { Stats.streak(history) }
    val today = remember(history) { Stats.todayMinutes(history) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Tarkeez", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    L.tr("خطّط لوقتك ثم أنجز بلا تشتيت", "Plan your time, then get it done"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (ready.first < ready.second) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        L.tr(
                            "الإعداد غير مكتمل (${ready.first} من ${ready.second}). قد لا يعمل القفل بشكل صحيح.",
                            "Setup incomplete (${ready.first} of ${ready.second}). Locking may not work properly."
                        ),
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = { Nav.tab = 3 }) { Text(L.tr("إصلاح", "Fix")) }
                }
            }
        }

        val s = session
        if (s != null) {
            ActiveSessionCard(s)
        } else {
            SummaryCard(today, settings.dailyGoalMin, streak)
            PlannerCard(a11yOk)
        }
    }
}

@Composable
private fun SummaryCard(todayMin: Int, goalMin: Int, streak: Int) {
    val goal = goalMin.coerceAtLeast(1)
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(
                progress = { todayMin.toFloat() / goal },
                modifier = Modifier.size(92.dp),
                stroke = 10.dp,
                color = MaterialTheme.colorScheme.secondary
            ) {
                Text(
                    "${(todayMin * 100 / goal).coerceAtMost(999)}%",
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(L.tr("تركيز اليوم", "Today's focus"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    L.tr("${fmtMin(todayMin)} من هدف ${fmtMin(goal)}", "${fmtMin(todayMin)} of ${fmtMin(goal)} goal"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.LocalFireDepartment, contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (streak > 0) L.tr("$streak أيام متتالية", "$streak day streak")
                        else L.tr("ابدأ سلسلتك اليوم", "Start your streak today"),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveSessionCard(s: Session) {
    val ctx = LocalContext.current
    SectionCard {
        if (s.phase == Phase.ASKING) {
            AskFlow(s)
            return@SectionCard
        }
        val onBreak = s.segment == Segment.BREAK
        val segTotal = (s.endMs - s.segStartMs).coerceAtLeast(1L)
        val nowState = rememberNow(500L)
        val pomo = s.pomo

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (s.lockActive) Icons.Rounded.Lock else Icons.Rounded.Timer,
                contentDescription = null, tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(8.dp))
            Text(
                when {
                    onBreak -> L.tr("استراحة", "Break")
                    s.locked -> L.tr("جلسة مقفلة", "Locked session")
                    else -> L.tr("جلسة جارية", "Session in progress")
                },
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
            )
            if (pomo != null) {
                Spacer(Modifier.weight(1f))
                Text(
                    L.tr("الدورة ${s.cycle + 1}/${pomo.cycles}", "Round ${s.cycle + 1}/${pomo.cycles}"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        if (s.title.isNotBlank()) {
            Text(s.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (s.note.isNotBlank()) {
            Text(s.note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            ProgressRing(
                progress = { 1f - ((s.endMs - nowState.value).coerceAtLeast(0L).toFloat() / segTotal) },
                modifier = Modifier.size(210.dp),
                stroke = 14.dp,
                color = if (onBreak) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
            ) {
                ClockText(
                    s.endMs,
                    MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                    MaterialTheme.colorScheme.onSurface
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        TaskChecklist(s.tasks) { SessionManager.toggleTask(it) }
        Spacer(Modifier.height(8.dp))
        if (s.lockActive) {
            Button(
                onClick = { SessionManager.launchLock(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(L.tr("افتح شاشة القفل", "Open lock screen")) }
        } else {
            Button(
                onClick = { SessionManager.finishEarly(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(L.tr("أنهيت مهامي", "I finished my tasks")) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { SessionManager.abandon(ctx) },
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text(L.tr("إلغاء الجلسة", "Cancel session")) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlannerCard(a11yOk: Boolean) {
    val ctx = LocalContext.current
    val tick = rememberTick()
    val settings by Store.settingsFlow.collectAsState()
    val templates by Store.templatesFlow.collectAsState()
    var showChoice by remember { mutableStateOf(false) }
    var manage by remember { mutableStateOf(false) }
    val builtins = remember(settings.language) { builtinTemplates() }
    val last = remember { Store.getLast() }

    fun commit() {
        val t = Draft.input.trim()
        if (t.isNotEmpty()) {
            Draft.tasks = Draft.tasks + t
            Draft.input = ""
        }
    }

    fun defaultPomo() = Pomo(settings.pomoFocus, settings.pomoBreak, settings.pomoLongBreak, settings.pomoCycles)

    SectionCard {
        Text(
            L.tr("ما الذي ستنجزه الآن؟", "What will you get done now?"),
            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))

        // قوالب سريعة
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (last != null) {
                FilterChip(
                    selected = false,
                    onClick = { tick(); Draft.apply(last) },
                    label = { Text(L.tr("↻ آخر جلسة", "↻ Last session")) }
                )
            }
            (builtins + templates).forEach { t ->
                FilterChip(selected = false, onClick = { tick(); Draft.apply(t) }, label = { Text(t.title) })
            }
        }
        if (templates.isNotEmpty()) {
            TextButton(onClick = { manage = true }) { Text(L.tr("إدارة قوالبي", "Manage my templates")) }
        }
        Spacer(Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = Draft.input,
                onValueChange = { Draft.input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(L.tr("اكتب مهمة ثم اضغط +", "Type a task, then tap +")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { commit() })
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { tick(); commit() }, enabled = Draft.input.isNotBlank()) {
                Icon(Icons.Rounded.Add, contentDescription = L.tr("إضافة", "Add"))
            }
        }
        Draft.tasks.forEachIndexed { i, t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                Text(t, modifier = Modifier.weight(1f))
                IconButton(onClick = { Draft.tasks = Draft.tasks.filterIndexed { j, _ -> j != i } }) {
                    Icon(Icons.Rounded.Close, contentDescription = L.tr("حذف", "Delete"), modifier = Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = Draft.title,
            onValueChange = { Draft.title = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(L.tr("اسم الجلسة (اختياري)", "Session name (optional)")) },
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = Draft.note,
            onValueChange = { Draft.note = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(L.tr("لماذا هذا مهم؟ (يظهر في شاشة القفل)", "Why does this matter? (shown on lock screen)")) },
            minLines = 2
        )
        Spacer(Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Pomodoro", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    L.tr("تركيز وراحة بالتناوب بمدد تحددها", "Alternate focus and breaks with your own lengths"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = Draft.pomoOn,
                onCheckedChange = {
                    tick()
                    Draft.pomoOn = it
                    if (it && Draft.pomo == null) Draft.pomo = defaultPomo()
                }
            )
        }
        Spacer(Modifier.height(8.dp))
        val p = Draft.pomo
        if (Draft.pomoOn && p != null) {
            PomoEditor(p) { Draft.pomo = it }
        } else {
            Text(L.tr("كم تتوقع أن تستغرق؟", "How long will it take?"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            DurationPicker(Draft.minutes) { Draft.minutes = it }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                commit()
                if (Draft.tasks.isNotEmpty()) showChoice = true
            },
            enabled = Draft.tasks.isNotEmpty() || Draft.input.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(L.tr("ابدأ التركيز", "Start focus"))
        }
        TextButton(
            onClick = {
                commit()
                if (Draft.tasks.isNotEmpty()) {
                    val name = Draft.title.trim().ifBlank { Draft.tasks.first() }
                    val pm = if (Draft.pomoOn) Draft.pomo else null
                    Store.putTemplates(
                        templates + Template(Store.nextId(), name, Draft.tasks, Draft.minutes, false, pm)
                    )
                }
            },
            enabled = Draft.tasks.isNotEmpty() || Draft.input.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text(L.tr("حفظ كقالب", "Save as template")) }
    }

    if (showChoice) {
        val pm = if (Draft.pomoOn) Draft.pomo else null
        val shownMin = if (pm != null) pm.focusMin * pm.cycles else Draft.minutes
        StartDialog(
            taskCount = Draft.tasks.size,
            minutes = shownMin,
            a11yOk = a11yOk,
            onChoose = { locked ->
                showChoice = false
                val minutes = if (pm != null) pm.focusMin else Draft.minutes
                if (SessionManager.start(ctx, Draft.tasks.toList(), minutes, locked, Draft.title.trim(), Draft.note.trim(), pm)) {
                    Draft.clear()
                    if (locked) SessionManager.launchLock(ctx)
                }
            },
            onSetup = {
                showChoice = false
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            onDismiss = { showChoice = false }
        )
    }

    if (manage) {
        AlertDialog(
            onDismissRequest = { manage = false },
            title = { Text(L.tr("قوالبي", "My templates")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    templates.forEach { t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${t.title} · ${fmtMin(t.minutes)}", modifier = Modifier.weight(1f))
                            IconButton(onClick = { Store.putTemplates(templates.filter { it.id != t.id }) }) {
                                Icon(Icons.Rounded.Close, contentDescription = L.tr("حذف", "Delete"))
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { manage = false }) { Text(L.tr("تم", "Done")) } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChoiceCard(
    icon: ImageVector,
    title: String,
    sub: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StartDialog(
    taskCount: Int,
    minutes: Int,
    a11yOk: Boolean,
    onChoose: (Boolean) -> Unit,
    onSetup: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L.tr("هل تريد قفل الهاتف حتى تنتهي المدة؟", "Lock the phone until time is up?")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    L.tr("$taskCount مهام · ${fmtMin(minutes)}", "$taskCount tasks · ${fmtMin(minutes)}"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ChoiceCard(
                    Icons.Rounded.Lock,
                    L.tr("نعم، اقفل الهاتف", "Yes, lock the phone"),
                    if (a11yOk) L.tr(
                        "تُحجب التطبيقات حتى ينتهي الوقت. تبقى المكالمات والرسائل متاحة.",
                        "Apps are blocked until time is up. Calls and messages stay available."
                    ) else L.tr("فعّل خدمة القفل أولاً.", "Enable the lock service first."),
                    enabled = a11yOk
                ) { onChoose(true) }
                ChoiceCard(
                    Icons.Rounded.LockOpen,
                    L.tr("لا، اتركه مفتوحاً", "No, leave it open"),
                    L.tr("سأذكّرك عند انتهاء الوقت فقط.", "I will only remind you when time is up.")
                ) { onChoose(false) }
                if (!a11yOk) TextButton(onClick = onSetup) { Text(L.tr("تفعيل خدمة القفل", "Enable lock service")) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(L.tr("إلغاء", "Cancel")) } }
    )
}
