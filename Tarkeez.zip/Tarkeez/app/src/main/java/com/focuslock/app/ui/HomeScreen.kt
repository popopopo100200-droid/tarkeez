package com.focuslock.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.focuslock.app.core.Perms
import com.focuslock.app.core.SessionManager
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Stats
import com.focuslock.app.data.Store
import kotlinx.coroutines.delay

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val session by Store.sessionFlow.collectAsState()
    val history by Store.historyFlow.collectAsState()
    val tick = rememberResumeTick()
    val a11yOk = remember(tick) { Perms.accessibilityEnabled(ctx) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(session?.id) {
        while (Store.session != null) {
            now = System.currentTimeMillis()
            SessionManager.checkExpiry(ctx)
            delay(1000)
        }
    }

    val streak = Stats.streak(history)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("تركيز", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    "خطّط لوقتك ثم أنجز بلا تشتيت",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (streak > 0) {
                Icon(
                    Icons.Rounded.LocalFireDepartment, contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.width(4.dp))
                Text("$streak يوم", fontWeight = FontWeight.Bold)
            }
        }

        if (!a11yOk) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "خدمة القفل غير مفعّلة، لذلك لن يعمل القفل.",
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                        Text("تفعيل")
                    }
                }
            }
        }

        val s = session
        if (s != null) {
            ActiveSessionCard(s, now)
        } else {
            PlannerCard(a11yOk)
        }
    }
}

@Composable
private fun ActiveSessionCard(s: com.focuslock.app.data.Session, now: Long) {
    val ctx = LocalContext.current
    SectionCard {
        if (s.phase == Phase.ASKING) {
            AskFlow(s)
            return@SectionCard
        }
        val remaining = (s.endMs - now).coerceAtLeast(0L)
        val total = (s.endMs - s.startMs).coerceAtLeast(1L)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (s.locked) Icons.Rounded.Lock else Icons.Rounded.Timer,
                contentDescription = null, tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(8.dp))
            Text(
                if (s.locked) "جلسة مقفلة" else "جلسة جارية",
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            fmtClock(remaining),
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )
        LinearProgressIndicator(
            progress = { (1f - remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
        Spacer(Modifier.height(8.dp))
        TaskChecklist(s.tasks) { SessionManager.toggleTask(it) }
        Spacer(Modifier.height(8.dp))
        if (s.locked) {
            Button(
                onClick = { SessionManager.launchLock(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("افتح شاشة القفل") }
        } else {
            Button(
                onClick = { SessionManager.finishEarly(ctx) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("أنهيت مهامي") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { SessionManager.abandon(ctx) },
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text("إلغاء الجلسة") }
        }
    }
}

@Composable
private fun PlannerCard(a11yOk: Boolean) {
    val ctx = LocalContext.current
    var tasks by rememberSaveable { mutableStateOf(ArrayList<String>()) }
    var input by rememberSaveable { mutableStateOf("") }
    var minutes by rememberSaveable { mutableIntStateOf(45) }
    var showChoice by remember { mutableStateOf(false) }

    fun commit() {
        val t = input.trim()
        if (t.isNotEmpty()) {
            tasks = ArrayList(tasks + t)
            input = ""
        }
    }

    SectionCard {
        Text("ما الذي ستنجزه الآن؟", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب مهمة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { commit() })
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { commit() }, enabled = input.isNotBlank()) {
                Icon(Icons.Rounded.Add, contentDescription = "إضافة")
            }
        }
        tasks.forEachIndexed { i, t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                Text(t, modifier = Modifier.weight(1f))
                IconButton(onClick = { tasks = ArrayList(tasks.filterIndexed { j, _ -> j != i }) }) {
                    Icon(Icons.Rounded.Close, contentDescription = "حذف", modifier = Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("كم تتوقع أن تستغرق؟", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        DurationPicker(minutes) { minutes = it }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                commit()
                if (tasks.isNotEmpty()) showChoice = true
            },
            enabled = tasks.isNotEmpty() || input.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("ابدأ التركيز")
        }
    }

    if (showChoice) {
        StartDialog(
            taskCount = tasks.size,
            minutes = minutes,
            a11yOk = a11yOk,
            onChoose = { locked ->
                showChoice = false
                if (SessionManager.start(ctx, tasks.toList(), minutes, locked)) {
                    tasks = ArrayList()
                    if (locked) SessionManager.launchLock(ctx)
                }
            },
            onSetup = {
                showChoice = false
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            onDismiss = { showChoice = false }
        )
    }
}

@Composable
private fun ChoiceCard(
    icon: ImageVector,
    title: String,
    sub: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(sub, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StartDialog(
    taskCount: Int,
    minutes: Int,
    a11yOk: Boolean,
    onChoose: (Boolean) -> Unit,
    onSetup: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("هل تريد قفل الهاتف حتى تنتهي المدة؟") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "$taskCount مهام · ${fmtMin(minutes)}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ChoiceCard(
                    Icons.Rounded.Lock,
                    "نعم، اقفل الهاتف",
                    if (a11yOk) "تُحجب التطبيقات حتى ينتهي الوقت. تبقى المكالمات والرسائل متاحة."
                    else "فعّل خدمة القفل أولاً.",
                    enabled = a11yOk
                ) { onChoose(true) }
                ChoiceCard(
                    Icons.Rounded.LockOpen,
                    "لا، اتركه مفتوحاً",
                    "سأذكّرك عند انتهاء الوقت فقط."
                ) { onChoose(false) }
                if (!a11yOk) TextButton(onClick = onSetup) { Text("تفعيل خدمة القفل") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
