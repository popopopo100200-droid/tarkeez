package com.focuslock.app.data

import android.content.Context
import android.content.SharedPreferences
import com.focuslock.app.core.Apps
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** تخزين محلي بسيط (SharedPreferences + JSON) مع تدفقات حالة تراقبها الواجهة. */
object Store {
    private lateinit var app: Context
    private var inited = false

    val sessionFlow = MutableStateFlow<Session?>(null)
    val historyFlow = MutableStateFlow<List<HistoryItem>>(emptyList())
    val schedulesFlow = MutableStateFlow<List<Schedule>>(emptyList())
    val settingsFlow = MutableStateFlow(AppSettings())

    val session: Session? get() = sessionFlow.value

    private fun prefs(): SharedPreferences =
        app.getSharedPreferences("focus_store", Context.MODE_PRIVATE)

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        app = ctx.applicationContext
        inited = true
        sessionFlow.value = readSession()
        historyFlow.value = readHistory()
        schedulesFlow.value = readSchedules()
        settingsFlow.value = readSettings()
    }

    fun nextId(): Long {
        val n = prefs().getLong("id_counter", 0L) + 1
        prefs().edit().putLong("id_counter", n).apply()
        return n
    }

    // ---------------- الجلسة ----------------

    fun putSession(s: Session?) {
        val e = prefs().edit()
        if (s == null) e.remove("session") else e.putString("session", sessionToJson(s).toString())
        e.commit()
        sessionFlow.value = s
    }

    private fun readSession(): Session? {
        val raw = prefs().getString("session", null) ?: return null
        return try {
            sessionFromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    private fun sessionToJson(s: Session): JSONObject {
        val tasks = JSONArray()
        s.tasks.forEach { tasks.put(JSONObject().put("t", it.text).put("d", it.done)) }
        return JSONObject()
            .put("id", s.id)
            .put("tasks", tasks)
            .put("planned", s.plannedMin)
            .put("start", s.startMs)
            .put("end", s.endMs)
            .put("locked", s.locked)
            .put("phase", s.phase.name)
            .put("ext", s.extensions)
            .put("extra", s.extraMin)
            .put("title", s.title)
            .put("note", s.note)
    }

    private fun sessionFromJson(o: JSONObject): Session {
        val a = o.getJSONArray("tasks")
        val tasks = (0 until a.length()).map {
            val t = a.getJSONObject(it)
            TaskItem(t.getString("t"), t.optBoolean("d", false))
        }
        return Session(
            id = o.getLong("id"),
            tasks = tasks,
            plannedMin = o.getInt("planned"),
            startMs = o.getLong("start"),
            endMs = o.getLong("end"),
            locked = o.getBoolean("locked"),
            phase = try { Phase.valueOf(o.optString("phase", "RUNNING")) } catch (e: Exception) { Phase.RUNNING },
            extensions = o.optInt("ext", 0),
            extraMin = o.optInt("extra", 0),
            title = o.optString("title", ""),
            note = o.optString("note", "")
        )
    }

    // ---------------- السجل ----------------

    fun addHistory(item: HistoryItem) {
        val list = (listOf(item) + historyFlow.value).take(500)
        historyFlow.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("s", it.startMs).put("e", it.endMs)
                    .put("p", it.plannedMin).put("a", it.actualMin)
                    .put("tt", it.tasksTotal).put("td", it.tasksDone)
                    .put("r", it.result.name).put("l", it.locked).put("x", it.extensions)
                    .put("ti", it.title)
            )
        }
        prefs().edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        historyFlow.value = emptyList()
        prefs().edit().remove("history").apply()
    }

    private fun readHistory(): List<HistoryItem> {
        val raw = prefs().getString("history", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                HistoryItem(
                    id = o.getLong("id"), startMs = o.getLong("s"), endMs = o.getLong("e"),
                    plannedMin = o.getInt("p"), actualMin = o.getInt("a"),
                    tasksTotal = o.getInt("tt"), tasksDone = o.getInt("td"),
                    result = Result.valueOf(o.getString("r")),
                    locked = o.getBoolean("l"), extensions = o.optInt("x", 0),
                    title = o.optString("ti", "")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------- الجدولة ----------------

    fun putSchedules(list: List<Schedule>) {
        schedulesFlow.value = list
        val arr = JSONArray()
        list.forEach {
            val days = JSONArray()
            it.days.forEach { d -> days.put(d) }
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("days", days)
                    .put("h", it.hour).put("m", it.minute).put("dur", it.durationMin)
                    .put("locked", it.locked).put("on", it.enabled)
            )
        }
        prefs().edit().putString("schedules", arr.toString()).apply()
    }

    private fun readSchedules(): List<Schedule> {
        val raw = prefs().getString("schedules", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val d = o.getJSONArray("days")
                Schedule(
                    id = o.getLong("id"), title = o.getString("title"),
                    days = (0 until d.length()).map { i -> d.getInt(i) }.toSet(),
                    hour = o.getInt("h"), minute = o.getInt("m"), durationMin = o.getInt("dur"),
                    locked = o.getBoolean("locked"), enabled = o.optBoolean("on", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------- الإعدادات ----------------

    fun saveSettings(s: AppSettings) {
        prefs().edit()
            .putString("lockMode", s.lockMode.name)
            .putStringSet("allowed", HashSet(s.allowedApps))
            .putStringSet("blocked", HashSet(s.blockedApps))
            .putInt("maxExt", s.maxExtensions)
            .putInt("exitDelay", s.exitDelaySec)
            .putString("pin", s.pin)
            .putBoolean("early", s.earlyFinish)
            .putBoolean("warn", s.warnBeforeEnd)
            .putBoolean("endAlert", s.endAlert)
            .putBoolean("protect", s.protectSettings)
            .putBoolean("onboarded", s.onboarded)
            .apply()
        settingsFlow.value = s
    }

    private fun readSettings(): AppSettings {
        val p = prefs()
        val allowed = p.getStringSet("allowed", null) ?: Apps.defaultAllowed(app)
        val mode = try {
            LockMode.valueOf(p.getString("lockMode", "") ?: "")
        } catch (e: Exception) {
            LockMode.ALL_EXCEPT_ALLOWED
        }
        return AppSettings(
            lockMode = mode,
            allowedApps = allowed.toSet(),
            blockedApps = (p.getStringSet("blocked", emptySet()) ?: emptySet()).toSet(),
            maxExtensions = p.getInt("maxExt", 3),
            exitDelaySec = p.getInt("exitDelay", 30),
            pin = p.getString("pin", "") ?: "",
            earlyFinish = p.getBoolean("early", false),
            warnBeforeEnd = p.getBoolean("warn", true),
            endAlert = p.getBoolean("endAlert", true),
            protectSettings = p.getBoolean("protect", true),
            onboarded = p.getBoolean("onboarded", false)
        )
    }
}
