package com.focuslock.app.data

import android.content.Context
import android.content.SharedPreferences
import com.focuslock.app.core.Apps
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** تخزين محلي بسيط (SharedPreferences + JSON) مع تدفقات حالة تراقبها الواجهة. */
object Store {
    private lateinit var app: Context
    private var inited = false

    val sessionFlow = MutableStateFlow<Session?>(null)
    val historyFlow = MutableStateFlow<List<HistoryItem>>(emptyList())
    val schedulesFlow = MutableStateFlow<List<Schedule>>(emptyList())
    val templatesFlow = MutableStateFlow<List<Template>>(emptyList())
    val attemptsFlow = MutableStateFlow<Map<String, Int>>(emptyMap())
    val settingsFlow = MutableStateFlow(AppSettings())

    /** ملخص آخر جلسة منتهية (يُعرض مرة واحدة ثم يُمسح). */
    val summaryFlow = MutableStateFlow<HistoryItem?>(null)

    val session: Session? get() = sessionFlow.value

    private fun prefs(): SharedPreferences =
        app.getSharedPreferences("focus_store", Context.MODE_PRIVATE)

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        app = ctx.applicationContext
        inited = true
        sessionFlow.value = readSession()
        historyFlow.value = readHistory()
        schedulesFlow.value = readSchedules()
        templatesFlow.value = readTemplates()
        attemptsFlow.value = readAttempts()
        settingsFlow.value = readSettings()
    }

    fun nextId(): Long {
        val n = prefs().getLong("id_counter", 0L) + 1
        prefs().edit().putLong("id_counter", n).apply()
        return n
    }

    // ---------------- بومودورو (JSON) ----------------

    private fun pomoToJson(p: Pomo): JSONObject =
        JSONObject().put("f", p.focusMin).put("b", p.breakMin).put("lb", p.longBreakMin).put("c", p.cycles)

    private fun pomoFromJson(o: JSONObject?): Pomo? {
        if (o == null) return null
        return Pomo(o.optInt("f", 25), o.optInt("b", 5), o.optInt("lb", 15), o.optInt("c", 4))
    }

    // ---------------- الجلسة ----------------

    fun putSession(s: Session?) {
        val e = prefs().edit()
        if (s == null) e.remove("session") else e.putString("session", sessionToJson(s).toString())
        e.commit()
        sessionFlow.value = s
    }

    private fun readSession(): Session? {
        val raw = prefs().getString("session", null) ?: return null
        return try {
            sessionFromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    private fun sessionToJson(s: Session): JSONObject {
        val tasks = JSONArray()
        s.tasks.forEach { tasks.put(JSONObject().put("t", it.text).put("d", it.done)) }
        val o = JSONObject()
            .put("id", s.id)
            .put("tasks", tasks)
            .put("planned", s.plannedMin)
            .put("start", s.startMs)
            .put("end", s.endMs)
            .put("locked", s.locked)
            .put("phase", s.phase.name)
            .put("ext", s.extensions)
            .put("extra", s.extraMin)
            .put("title", s.title)
            .put("note", s.note)
            .put("seg", s.segment.name)
            .put("cycle", s.cycle)
            .put("segStart", s.segStartMs)
            .put("breakDone", s.breakDoneMin)
            .put("attempts", s.attempts)
        val p = s.pomo
        if (p != null) o.put("pomo", pomoToJson(p))
        return o
    }

    private fun sessionFromJson(o: JSONObject): Session {
        val a = o.getJSONArray("tasks")
        val tasks = (0 until a.length()).map {
            val t = a.getJSONObject(it)
            TaskItem(t.getString("t"), t.optBoolean("d", false))
        }
        return Session(
            id = o.getLong("id"),
            tasks = tasks,
            plannedMin = o.getInt("planned"),
            startMs = o.getLong("start"),
            endMs = o.getLong("end"),
            locked = o.getBoolean("locked"),
            phase = try { Phase.valueOf(o.optString("phase", "RUNNING")) } catch (e: Exception) { Phase.RUNNING },
            extensions = o.optInt("ext", 0),
            extraMin = o.optInt("extra", 0),
            title = o.optString("title", ""),
            note = o.optString("note", ""),
            pomo = pomoFromJson(o.optJSONObject("pomo")),
            segment = try { Segment.valueOf(o.optString("seg", "FOCUS")) } catch (e: Exception) { Segment.FOCUS },
            cycle = o.optInt("cycle", 0),
            segStartMs = o.optLong("segStart", o.getLong("start")),
            breakDoneMin = o.optInt("breakDone", 0),
            attempts = o.optInt("attempts", 0)
        )
    }

    // ---------------- السجل ----------------

    fun addHistory(item: HistoryItem) {
        val list = (listOf(item) + historyFlow.value).take(500)
        historyFlow.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("s", it.startMs).put("e", it.endMs)
                    .put("p", it.plannedMin).put("a", it.actualMin)
                    .put("tt", it.tasksTotal).put("td", it.tasksDone)
                    .put("r", it.result.name).put("l", it.locked).put("x", it.extensions)
                    .put("ti", it.title).put("at", it.attempts)
            )
        }
        prefs().edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        historyFlow.value = emptyList()
        prefs().edit().remove("history").apply()
    }

    private fun readHistory(): List<HistoryItem> {
        val raw = prefs().getString("history", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                HistoryItem(
                    id = o.getLong("id"), startMs = o.getLong("s"), endMs = o.getLong("e"),
                    plannedMin = o.getInt("p"), actualMin = o.getInt("a"),
                    tasksTotal = o.getInt("tt"), tasksDone = o.getInt("td"),
                    result = Result.valueOf(o.getString("r")),
                    locked = o.getBoolean("l"), extensions = o.optInt("x", 0),
                    title = o.optString("ti", ""), attempts = o.optInt("at", 0)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------- الجدولة ----------------

    fun putSchedules(list: List<Schedule>) {
        schedulesFlow.value = list
        val arr = JSONArray()
        list.forEach {
            val days = JSONArray()
            it.days.forEach { d -> days.put(d) }
            arr.put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("days", days)
                    .put("h", it.hour).put("m", it.minute).put("dur", it.durationMin)
                    .put("locked", it.locked).put("on", it.enabled)
            )
        }
        prefs().edit().putString("schedules", arr.toString()).apply()
    }

    private fun readSchedules(): List<Schedule> {
        val raw = prefs().getString("schedules", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val d = o.getJSONArray("days")
                Schedule(
                    id = o.getLong("id"), title = o.getString("title"),
                    days = (0 until d.length()).map { i -> d.getInt(i) }.toSet(),
                    hour = o.getInt("h"), minute = o.getInt("m"), durationMin = o.getInt("dur"),
                    locked = o.getBoolean("locked"), enabled = o.optBoolean("on", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------- القوالب وآخر جلسة ----------------

    private fun templateToJson(t: Template): JSONObject {
        val tasks = JSONArray()
        t.tasks.forEach { tasks.put(it) }
        val o = JSONObject()
            .put("id", t.id).put("title", t.title).put("tasks", tasks)
            .put("min", t.minutes).put("locked", t.locked)
        val p = t.pomo
        if (p != null) o.put("pomo", pomoToJson(p))
        return o
    }

    private fun templateFromJson(o: JSONObject): Template {
        val a = o.getJSONArray("tasks")
        return Template(
            id = o.getLong("id"),
            title = o.optString("title", ""),
            tasks = (0 until a.length()).map { a.getString(it) },
            minutes = o.getInt("min"),
            locked = o.optBoolean("locked", false),
            pomo = pomoFromJson(o.optJSONObject("pomo"))
        )
    }

    fun putTemplates(list: List<Template>) {
        templatesFlow.value = list
        val arr = JSONArray()
        list.forEach { arr.put(templateToJson(it)) }
        prefs().edit().putString("templates", arr.toString()).apply()
    }

    private fun readTemplates(): List<Template> {
        val raw = prefs().getString("templates", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { templateFromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun putLast(t: Template) {
        prefs().edit().putString("last", templateToJson(t).toString()).apply()
    }

    fun getLast(): Template? {
        val raw = prefs().getString("last", null) ?: return null
        return try {
            templateFromJson(JSONObject(raw))
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- محاولات فتح تطبيقات محجوبة ----------------

    fun recordAttempt(pkg: String) {
        val m = attemptsFlow.value.toMutableMap()
        m[pkg] = (m[pkg] ?: 0) + 1
        attemptsFlow.value = m
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v) }
        prefs().edit().putString("attempts", o.toString()).apply()
        val s = session
        if (s != null) putSession(s.copy(attempts = s.attempts + 1))
    }

    private fun readAttempts(): Map<String, Int> {
        val raw = prefs().getString("attempts", null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val m = HashMap<String, Int>()
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                m[k] = o.optInt(k, 0)
            }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun clearAttempts() {
        attemptsFlow.value = emptyMap()
        prefs().edit().remove("attempts").apply()
    }

    // ---------------- حالة عدم الإزعاج السابقة ----------------

    fun dndPrev(): Int = prefs().getInt("dnd_prev", -1)

    fun setDndPrev(v: Int) {
        prefs().edit().putInt("dnd_prev", v).commit()
    }

    // ---------------- الإعدادات ----------------

    fun saveSettings(s: AppSettings) {
        prefs().edit()
            .putString("lockMode", s.lockMode.name)
            .putStringSet("allowed", HashSet(s.allowedApps))
            .putStringSet("blocked", HashSet(s.blockedApps))
            .putInt("maxExt", s.maxExtensions)
            .putInt("exitDelay", s.exitDelaySec)
            .putString("pin", s.pin)
            .putBoolean("early", s.earlyFinish)
            .putBoolean("warn", s.warnBeforeEnd)
            .putBoolean("endAlert", s.endAlert)
            .putBoolean("protect", s.protectSettings)
            .putBoolean("onboarded", s.onboarded)
            .putString("lang", s.language)
            .putString("theme", s.theme.name)
            .putBoolean("dnd", s.dnd)
            .putInt("goal", s.dailyGoalMin)
            .putInt("pFocus", s.pomoFocus)
            .putInt("pBreak", s.pomoBreak)
            .putInt("pLong", s.pomoLongBreak)
            .putInt("pCycles", s.pomoCycles)
            .apply()
        settingsFlow.value = s
    }

    private fun readSettings(): AppSettings {
        val p = prefs()
        val allowed = p.getStringSet("allowed", null) ?: Apps.defaultAllowed(app)
        val mode = try {
            LockMode.valueOf(p.getString("lockMode", "") ?: "")
        } catch (e: Exception) {
            LockMode.ALL_EXCEPT_ALLOWED
        }
        val theme = try {
            ThemeMode.valueOf(p.getString("theme", "") ?: "")
        } catch (e: Exception) {
            ThemeMode.AUTO
        }
        return AppSettings(
            lockMode = mode,
            allowedApps = allowed.toSet(),
            blockedApps = (p.getStringSet("blocked", emptySet()) ?: emptySet()).toSet(),
            maxExtensions = p.getInt("maxExt", 3),
            exitDelaySec = p.getInt("exitDelay", 30),
            pin = p.getString("pin", "") ?: "",
            earlyFinish = p.getBoolean("early", false),
            warnBeforeEnd = p.getBoolean("warn", true),
            endAlert = p.getBoolean("endAlert", true),
            protectSettings = p.getBoolean("protect", true),
            onboarded = p.getBoolean("onboarded", false),
            language = p.getString("lang", "auto") ?: "auto",
            theme = theme,
            dnd = p.getBoolean("dnd", false),
            dailyGoalMin = p.getInt("goal", 120),
            pomoFocus = p.getInt("pFocus", 25),
            pomoBreak = p.getInt("pBreak", 5),
            pomoLongBreak = p.getInt("pLong", 15),
            pomoCycles = p.getInt("pCycles", 4)
        )
    }
}
