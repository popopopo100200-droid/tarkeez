package com.focuslock.app.core

import android.content.Context
import android.content.Intent
import com.focuslock.app.data.HistoryItem
import com.focuslock.app.data.Phase
import com.focuslock.app.data.Result
import com.focuslock.app.data.Session
import com.focuslock.app.data.Store
import com.focuslock.app.data.TaskItem
import com.focuslock.app.ui.LockActivity

/** كل منطق دورة حياة الجلسة: بدء، تنبيه، سؤال النهاية، تمديد، إنهاء. */
object SessionManager {
    const val ACTION_END = "com.focuslock.app.SESSION_END"
    const val ACTION_WARN = "com.focuslock.app.SESSION_WARN"
    private const val RC_END = 101
    private const val RC_WARN = 102

    fun canExtend(s: Session): Boolean {
        val cap = Store.settingsFlow.value.maxExtensions
        return cap <= 0 || s.extensions < cap
    }

    fun start(
        ctx: Context,
        tasks: List<String>,
        minutes: Int,
        locked: Boolean,
        title: String = "",
        note: String = ""
    ): Boolean {
        if (Store.session != null || tasks.isEmpty()) return false
        val now = System.currentTimeMillis()
        val s = Session(
            id = now,
            tasks = tasks.map { TaskItem(it) },
            plannedMin = minutes,
            startMs = now,
            endMs = now + minutes * 60_000L,
            locked = locked,
            title = title,
            note = note
        )
        Store.putSession(s)
        armAlarms(ctx, s)
        Notifier.showOngoing(ctx, s)
        return true
    }

    fun armAlarms(ctx: Context, s: Session) {
        Alarms.set(ctx, s.endMs, Alarms.broadcast(ctx, RC_END, ACTION_END))
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
        val warnAt = s.endMs - 2 * 60_000L
        if (Store.settingsFlow.value.warnBeforeEnd &&
            s.phase == Phase.RUNNING &&
            warnAt > System.currentTimeMillis() + 30_000L
        ) {
            Alarms.set(ctx, warnAt, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
        }
    }

    private fun cancelAlarms(ctx: Context) {
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_END, ACTION_END))
        Alarms.cancel(ctx, Alarms.broadcast(ctx, RC_WARN, ACTION_WARN))
    }

    /** شبكة أمان: إن تأخر المنبّه ننتقل لمرحلة السؤال عند أول فرصة. */
    fun checkExpiry(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING && System.currentTimeMillis() >= s.endMs) onEnd(ctx)
    }

    fun onWarn(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING) {
            Notifier.showWarn(ctx, s)
            Alerts.warnAlert(ctx)
        }
    }

    fun onEnd(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.ASKING) return
        // منبّه قديم بعد تمديد الوقت
        if (System.currentTimeMillis() < s.endMs - 1500L) return
        Store.putSession(s.copy(phase = Phase.ASKING))
        Notifier.showAsk(ctx, s)
        Alerts.endAlert(ctx)
        if (s.locked) launchLock(ctx)
    }

    fun launchLock(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(ctx, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (e: Exception) { /* قد يمنعه النظام من الخلفية؛ الإشعار وخدمة القفل يتكفّلان */ }
    }

    fun toggleTask(index: Int) {
        val s = Store.session ?: return
        if (index !in s.tasks.indices) return
        val t = s.tasks.toMutableList()
        t[index] = t[index].copy(done = !t[index].done)
        Store.putSession(s.copy(tasks = t))
    }

    // ----------- إجابات سؤال النهاية -----------

    /** "نعم، أنجزت مهامي" */
    fun answerYes(ctx: Context) = finish(ctx, Result.COMPLETED, markAllDone = true)

    /** "ما أنجزته يكفي" */
    fun answerEnough(ctx: Context) = finish(ctx, Result.PARTIAL)

    /** خروج طارئ أو إلغاء: يُسجَّل كجلسة ملغاة ويكسر السلسلة. */
    fun abandon(ctx: Context) = finish(ctx, Result.ABANDONED)

    /** إنهاء مبكر عند إنجاز كل المهام. */
    fun finishEarly(ctx: Context) = finish(ctx, Result.COMPLETED, markAllDone = true)

    /** "لا، لم أكمل" ثم تحديد مدة إضافية. يعيد false إن بلغنا الحد الأقصى للتمديد. */
    fun extend(ctx: Context, minutes: Int, lock: Boolean? = null): Boolean {
        val s = Store.session ?: return false
        if (!canExtend(s)) return false
        val now = System.currentTimeMillis()
        val newLocked = lock ?: s.locked
        val n = s.copy(
            phase = Phase.RUNNING,
            endMs = now + minutes * 60_000L,
            extensions = s.extensions + 1,
            extraMin = s.extraMin + minutes,
            locked = newLocked
        )
        Store.putSession(n)
        armAlarms(ctx, n)
        Notifier.showOngoing(ctx, n)
        if (newLocked && !s.locked) launchLock(ctx)
        return true
    }

    private fun finish(ctx: Context, result: Result, markAllDone: Boolean = false) {
        val s = Store.session ?: return
        val now = System.currentTimeMillis()
        val tasks = if (markAllDone) s.tasks.map { it.copy(done = true) } else s.tasks
        val endEff = minOf(now, s.endMs)
        val actualMin = ((endEff - s.startMs) / 60_000L).toInt().coerceAtLeast(0)
        Store.addHistory(
            HistoryItem(
                id = s.id, startMs = s.startMs, endMs = now,
                plannedMin = s.plannedMin, actualMin = actualMin,
                tasksTotal = tasks.size, tasksDone = tasks.count { it.done },
                result = result, locked = s.locked, extensions = s.extensions,
                title = s.title
            )
        )
        Store.putSession(null)
        cancelAlarms(ctx)
        Notifier.cancelSession(ctx)
    }

    /** بعد إعادة تشغيل الجهاز أو تحديث التطبيق. */
    fun restore(ctx: Context) {
        val s = Store.session ?: return
        if (s.phase == Phase.RUNNING && System.currentTimeMillis() >= s.endMs) {
            onEnd(ctx)
            return
        }
        armAlarms(ctx, s)
        if (s.phase == Phase.ASKING) Notifier.showAsk(ctx, s) else Notifier.showOngoing(ctx, s)
    }
}
