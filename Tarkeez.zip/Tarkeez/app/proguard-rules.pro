# قواعد R8 الافتراضية كافية لهذا التطبيق.
-keep class com.focuslock.app.core.BlockerService { *; }
-keep class com.focuslock.app.core.AdminReceiver { *; }
